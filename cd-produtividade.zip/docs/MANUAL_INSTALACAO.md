# Manual de Instalação

Caminho: `docs/MANUAL_INSTALACAO.md`

## 1. Pré-requisitos

- Docker e Docker Compose instalados no servidor
- Portas livres: `5432` (banco), `3333` (API), `8080` (frontend)
- (Opcional, para desenvolvimento sem Docker) Node.js 20+, PostgreSQL 16+

## 2. Instalação com Docker (recomendado para produção)

```bash
git clone <repositorio> cd-produtividade
cd cd-produtividade

# Copie e ajuste as variáveis de ambiente do backend
cp backend/.env.example backend/.env
# Edite backend/.env e troque:
#   - JWT_SECRET e JWT_REFRESH_SECRET (use valores longos e aleatórios)
#   - DATABASE_URL (usuário/senha do Postgres, se for alterar os padrões)

# Suba tudo
docker compose up -d --build
```

Isso vai:
1. Subir o PostgreSQL
2. Buildar e subir a API (`backend`), aplicando as migrations automaticamente no start
3. Buildar e subir o frontend (servido via Nginx)

## 3. Popular dados iniciais (setores, turnos, usuário administrador)

```bash
docker compose exec backend npm run prisma:seed
```

Isso cria:
- Setores de exemplo (Recebimento, Expedição, Armazenagem)
- Turnos (Manhã, Tarde, Noite)
- Usuário administrador: **login `admin` / senha `admin123`**

**Troque a senha do administrador imediatamente após o primeiro acesso.**

## 4. Acessando o sistema

- Frontend: `http://<ip-do-servidor>:8080`
- API: `http://<ip-do-servidor>:3333/api/v1`
- Documentação da API (Swagger): `http://<ip-do-servidor>:3333/api/docs`

## 5. Instalação para desenvolvimento (sem Docker)

### Backend
```bash
cd backend
cp .env.example .env   # aponte DATABASE_URL para seu Postgres local
npm install
npx prisma migrate dev
npm run prisma:seed
npm run start:dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## 6. Atualizando o sistema (nova versão)

```bash
git pull
docker compose up -d --build
docker compose exec backend npx prisma migrate deploy
```

## 7. Backup do banco de dados

```bash
docker compose exec db pg_dump -U cd_admin cd_produtividade > backup-$(date +%Y%m%d).sql
```

## 8. Solução de problemas comuns

| Sintoma | Causa provável | Solução |
|---|---|---|
| Frontend não conecta na API | `VITE_API_URL` incorreto no build | Rebuild com `--build-arg` correto ou edite `docker-compose.yml` |
| Erro 401 constante | `JWT_SECRET` divergente entre reinícios | Garanta que `.env` não muda entre deploys |
| Erro ao iniciar atividade duplicada | Comportamento esperado (regra de negócio) | Funcionário deve encerrar a atividade atual primeiro |
| Migrations não aplicam | Banco não acessível no start do container | Verifique `depends_on`/healthcheck no `docker-compose.yml` |

# Manual do Administrador e Supervisor

Caminho: `docs/MANUAL_ADMINISTRADOR.md`

## 1. Perfis de acesso

| Permissão | O que pode fazer |
|---|---|
| **Funcionário** | Iniciar/encerrar suas próprias atividades, trocar a própria senha |
| **Supervisor** | Tudo do funcionário + gerenciar funcionários, ver dashboard, gerar relatórios, iniciar/encerrar atividade em nome de outro funcionário |
| **Administrador** | Tudo do supervisor + inativar funcionários, acesso irrestrito |

## 2. Dashboard em tempo real

Ao logar como administrador/supervisor, você cai direto no **Painel do Gestor**, que mostra, atualizado automaticamente (sem precisar recarregar a página):

- Quantos funcionários estão trabalhando agora / parados
- Em qual atividade cada um está, e há quanto tempo
- Pedidos e itens processados no dia
- Tempo médio por atividade e por pedido
- Pedidos/hora e itens/hora
- Ranking de produtividade (mais pedidos/hora)
- Ranking de tempo ocioso (quem está há mais tempo sem atividade aberta)

## 3. Cadastro de funcionários

Endpoint: `POST /api/v1/funcionarios` (via API — a tela de cadastro no front pode ser construída reaproveitando o formulário de login como referência de estilo).

Campos obrigatórios: nome, matrícula (única), cargo, login (único), senha (mín. 6 caracteres), permissão, setor.

**Importante:** a senha nunca é retornada pela API, nem armazenada em texto puro — apenas o hash (bcrypt).

## 4. Inativando um funcionário

Apenas administradores podem inativar (`DELETE /api/v1/funcionarios/:id`). Isso:
- Impede novos logins do funcionário
- **Preserva todo o histórico de atividades** para fins de relatório e auditoria

## 5. Relatórios

Disponíveis por funcionário, equipe ou setor, nos períodos: diário, semanal, mensal ou personalizado (informando data início/fim).

Cada relatório traz: tempo total trabalhado, tempo por tipo de atividade, tempo ocioso, quantidade de pedidos/itens, tempo médio por pedido, pedidos/hora, itens/hora, eficiência, aproveitamento da jornada e histórico completo.

Exportação disponível em **Excel** e **PDF** diretamente pelos endpoints:
- `GET /relatorios/funcionario/:id/exportar/excel`
- `GET /relatorios/funcionario/:id/exportar/pdf`

## 6. Auditoria

Toda criação, atualização e exclusão de funcionário, além de tentativas de login (com sucesso ou falha), fica registrada na tabela `logs_auditoria`, com o autor da ação, dados antes/depois e IP de origem. Isso não é exposto em tela por padrão — consulte diretamente no banco ou solicite um relatório de auditoria à equipe técnica.

## 7. Boas práticas de gestão

- Revise o **ranking de tempo ocioso** diariamente — funcionários parados por muito tempo podem indicar gargalo de processo, não necessariamente ociosidade real.
- Use os filtros por setor/equipe/turno do dashboard para comparar performance entre grupos, não apenas indivíduos.
- Ao identificar um registro com dado claramente errado (ex.: 999 pedidos em 1 minuto), corrija via suporte técnico — o sistema não permite edição direta de registros históricos pela interface, por integridade dos dados.

## 8. Segurança

- Troque `JWT_SECRET`, `JWT_REFRESH_SECRET` e as senhas do banco antes de colocar em produção (ver Manual de Instalação).
- Ao trocar a senha de um funcionário, todos os tokens de sessão dele são revogados automaticamente.
- Cada troca de senha, login e alteração cadastral fica registrada em auditoria.

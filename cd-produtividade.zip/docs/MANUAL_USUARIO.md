# Manual do Usuário (Funcionário)

Caminho: `docs/MANUAL_USUARIO.md`

## 1. Acessando o sistema

1. Abra o endereço informado pelo seu supervisor (ex.: `http://192.168.x.x:8080`) no computador, tablet ou celular.
2. Informe seu **login** e **senha** cadastrados.
3. Toque em **Entrar**.

## 2. Tela principal

Após o login, você verá botões grandes, um para cada atividade:

- Separação
- Picking
- Conferência
- Embalagem
- Recebimento
- Inventário

## 3. Iniciando uma atividade

Toque no botão da atividade que você vai começar (ex.: **Iniciar Separação**).
O sistema:
- Registra automaticamente o horário de início
- Mostra um cronômetro no topo da tela com o tempo decorrido
- Bloqueia os outros botões — você só pode ter **uma atividade aberta por vez**

## 4. Encerrando uma atividade

Toque novamente no botão da atividade em andamento (ele fica vermelho, escrito **Encerrar**).
Uma janela vai pedir:
- **Quantidade de pedidos** processados
- **Quantidade de itens** processados
- **Observações** (opcional — use para relatar qualquer ocorrência)

Toque em **Confirmar encerramento**. O sistema calcula automaticamente quanto tempo você levou.

## 5. Dúvidas comuns

**"Não consigo iniciar outra atividade."**
Você já tem uma atividade em aberto. Encerre-a primeiro.

**"Fechei o navegador no meio da atividade, e agora?"**
Sem problema — ao logar novamente, o sistema reconhece automaticamente que você ainda tem uma atividade aberta e mostra o cronômetro correndo de onde parou.

**"Errei a quantidade de pedidos/itens ao encerrar."**
Avise seu supervisor — ele pode corrigir o registro no sistema.

**"Esqueci minha senha."**
Peça ao seu supervisor ou administrador para redefinir.

## 6. Boas práticas

- Sempre encerre a atividade atual antes de sair para o intervalo ou trocar de tarefa.
- Preencha a quantidade de pedidos/itens com atenção — esses números alimentam os relatórios de produtividade da equipe.
- Use o campo de observações para relatar problemas (ex.: "pedido com divergência de estoque").

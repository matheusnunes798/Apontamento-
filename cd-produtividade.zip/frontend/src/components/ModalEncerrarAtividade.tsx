// Caminho: frontend/src/components/ModalEncerrarAtividade.tsx

import { FormEvent, useState } from 'react';
import { TipoAtividade, AtividadeLabel } from '../services/dominio';
import { formatarHMS } from '../hooks/useCronometro';

interface Props {
  tipo: TipoAtividade;
  segundosDecorridos: number;
  aoConfirmar: (dados: { quantidadePedidos: number; quantidadeItens: number; observacoes: string }) => void;
  aoCancelar: () => void;
}

export default function ModalEncerrarAtividade({ tipo, segundosDecorridos, aoConfirmar, aoCancelar }: Props) {
  const [pedidos, setPedidos] = useState('');
  const [itens, setItens] = useState('');
  const [observacoes, setObservacoes] = useState('');

  function aoEnviar(e: FormEvent) {
    e.preventDefault();
    aoConfirmar({
      quantidadePedidos: Number(pedidos) || 0,
      quantidadeItens: Number(itens) || 0,
      observacoes,
    });
  }

  return (
    <div className="fixed inset-0 bg-black/70 flex items-end sm:items-center justify-center z-50 p-4">
      <div className="w-full max-w-md bg-painel border border-borda rounded-2xl p-6 shadow-painel">
        <p className="font-mono text-xs uppercase tracking-widest text-texto-muted mb-1">
          Encerrando
        </p>
        <h2 className="font-display text-2xl font-bold mb-1">{AtividadeLabel[tipo]}</h2>
        <p className="font-mono text-3xl font-bold text-operacao mb-6">
          {formatarHMS(segundosDecorridos)}
        </p>

        <form onSubmit={aoEnviar}>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <label className="block">
              <span className="block text-sm text-texto-muted mb-1.5">Pedidos</span>
              <input
                inputMode="numeric"
                value={pedidos}
                onChange={(e) => setPedidos(e.target.value.replace(/\D/g, ''))}
                className="foco-visivel w-full rounded-xl bg-painel-alt border border-borda px-4 py-3 text-lg"
                placeholder="0"
              />
            </label>
            <label className="block">
              <span className="block text-sm text-texto-muted mb-1.5">Itens</span>
              <input
                inputMode="numeric"
                value={itens}
                onChange={(e) => setItens(e.target.value.replace(/\D/g, ''))}
                className="foco-visivel w-full rounded-xl bg-painel-alt border border-borda px-4 py-3 text-lg"
                placeholder="0"
              />
            </label>
          </div>

          <label className="block mb-6">
            <span className="block text-sm text-texto-muted mb-1.5">Observações (opcional)</span>
            <textarea
              value={observacoes}
              onChange={(e) => setObservacoes(e.target.value)}
              className="foco-visivel w-full rounded-xl bg-painel-alt border border-borda px-4 py-3 text-base"
              rows={2}
            />
          </label>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={aoCancelar}
              className="foco-visivel flex-1 rounded-xl border border-borda py-3.5 font-semibold text-texto-muted"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="foco-visivel flex-1 rounded-xl bg-encerrar py-3.5 font-semibold text-white"
            >
              Confirmar encerramento
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Caminho: frontend/src/components/CartaoIndicador.tsx

interface Props {
  rotulo: string;
  valor: string | number;
  destaque?: 'operacao' | 'ocioso' | 'encerrar' | 'info';
}

const CORES: Record<NonNullable<Props['destaque']>, string> = {
  operacao: 'text-operacao',
  ocioso: 'text-ocioso',
  encerrar: 'text-encerrar',
  info: 'text-info',
};

export default function CartaoIndicador({ rotulo, valor, destaque }: Props) {
  return (
    <div className="rounded-2xl border border-borda bg-painel p-5">
      <p className="font-mono text-[11px] uppercase tracking-widest text-texto-muted mb-2">
        {rotulo}
      </p>
      <p className={`font-display text-3xl font-bold ${destaque ? CORES[destaque] : 'text-texto'}`}>
        {valor}
      </p>
    </div>
  );
}

// Caminho: frontend/src/components/BotaoAtividade.tsx

import { TipoAtividade, AtividadeLabel } from '../services/dominio';

interface Props {
  tipo: TipoAtividade;
  emAndamento: boolean;
  bloqueado: boolean;
  aoClicar: () => void;
}

export default function BotaoAtividade({ tipo, emAndamento, bloqueado, aoClicar }: Props) {
  return (
    <button
      onClick={aoClicar}
      disabled={bloqueado && !emAndamento}
      className={[
        'foco-visivel group relative w-full rounded-2xl border p-6 text-left transition',
        'flex items-center justify-between gap-4 min-h-[92px]',
        emAndamento
          ? 'bg-encerrar/10 border-encerrar text-texto'
          : 'bg-painel border-borda hover:border-operacao/60',
        bloqueado && !emAndamento ? 'opacity-40 cursor-not-allowed' : 'active:scale-[0.98]',
      ].join(' ')}
    >
      <span className="flex items-center gap-4">
        <span
          className={[
            'h-3.5 w-3.5 rounded-full shrink-0',
            emAndamento ? 'bg-encerrar animate-pulse' : 'bg-operacao',
          ].join(' ')}
        />
        <span className="font-display text-xl font-bold">{AtividadeLabel[tipo]}</span>
      </span>
      <span className="font-mono text-sm uppercase tracking-wide text-texto-muted group-hover:text-texto">
        {emAndamento ? 'Encerrar' : 'Iniciar'}
      </span>
    </button>
  );
}

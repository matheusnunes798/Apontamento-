// Caminho: frontend/src/components/RotaProtegida.tsx

import { Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Permissao } from '../services/dominio';

export default function RotaProtegida({
  children,
  permissoesPermitidas,
}: {
  children: JSX.Element;
  permissoesPermitidas?: Permissao[];
}) {
  const { usuario } = useAuth();

  if (!usuario) return <Navigate to="/login" replace />;

  if (permissoesPermitidas && !permissoesPermitidas.includes(usuario.permissao)) {
    return <Navigate to="/" replace />;
  }

  return children;
}

// Caminho: frontend/src/contexts/AuthContext.tsx

import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { authService, FuncionarioLogado } from '../services/dominio';

interface AuthContextValue {
  usuario: FuncionarioLogado | null;
  carregando: boolean;
  erro: string | null;
  entrar: (login: string, senha: string) => Promise<void>;
  sair: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<FuncionarioLogado | null>(authService.usuarioAtual());
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  const entrar = useCallback(async (login: string, senha: string) => {
    setCarregando(true);
    setErro(null);
    try {
      const funcionario = await authService.login(login, senha);
      setUsuario(funcionario);
    } catch {
      setErro('Login ou senha inválidos.');
      throw new Error('falha-login');
    } finally {
      setCarregando(false);
    }
  }, []);

  const sair = useCallback(async () => {
    await authService.logout();
    setUsuario(null);
  }, []);

  return (
    <AuthContext.Provider value={{ usuario, carregando, erro, entrar, sair }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de <AuthProvider>.');
  return ctx;
}

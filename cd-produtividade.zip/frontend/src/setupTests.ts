// Caminho: frontend/src/setupTests.ts

import '@testing-library/jest-dom';

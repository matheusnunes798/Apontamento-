// Caminho: frontend/src/App.tsx

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import RotaProtegida from './components/RotaProtegida';
import Login from './pages/Login';
import FuncionarioPainel from './pages/FuncionarioPainel';
import GestorDashboard from './pages/GestorDashboard';

function RaizPorPermissao() {
  const { usuario } = useAuth();
  if (usuario && (usuario.permissao === 'ADMINISTRADOR' || usuario.permissao === 'SUPERVISOR')) {
    return <GestorDashboard />;
  }
  return <FuncionarioPainel />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <RotaProtegida>
                <RaizPorPermissao />
              </RotaProtegida>
            }
          />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

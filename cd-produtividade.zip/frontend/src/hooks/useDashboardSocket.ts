// Caminho: frontend/src/hooks/useDashboardSocket.ts

import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

export interface SnapshotDashboard {
  funcionariosAtivos: number;
  funcionariosParados: number;
  emAndamento: Array<{
    funcionarioId: string;
    nome: string;
    matricula: string;
    atividade: string;
    iniciadaEm: string;
    segundosEmAndamento: number;
  }>;
  parados: Array<{
    funcionarioId: string;
    nome: string;
    matricula: string;
    paradoDesde: string | null;
    segundosParado: number | null;
  }>;
  resumoAtividades: {
    pedidosEmAndamento: number;
    pedidosConcluidos: number;
    itensProcessados: number;
    tempoMedioPorAtividadeSegundos: number;
    tempoMedioPorPedidoSegundos: number;
    pedidosPorHora: number;
    itensPorHora: number;
  };
  ranking: {
    produtividade: Array<{ funcionarioId: string; nome: string; pedidosPorHora: number }>;
    tempoOcioso: Array<{ funcionarioId: string; nome: string; segundos: number }>;
  };
  atualizadoEm: string;
}

interface FiltroDashboard {
  setorId?: string;
  equipeId?: string;
  turnoId?: string;
}

const SOCKET_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:3333';

export function useDashboardSocket(filtro: FiltroDashboard) {
  const [snapshot, setSnapshot] = useState<SnapshotDashboard | null>(null);
  const [conectado, setConectado] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    const socket = io(`${SOCKET_URL}/dashboard`, { transports: ['websocket'] });
    socketRef.current = socket;

    socket.on('connect', () => {
      setConectado(true);
      socket.emit('dashboard:solicitar-snapshot', filtro);
    });

    socket.on('disconnect', () => setConectado(false));
    socket.on('dashboard:snapshot', (dados: SnapshotDashboard) => setSnapshot(dados));

    return () => {
      socket.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtro.setorId, filtro.equipeId, filtro.turnoId]);

  const solicitarAtualizacao = () => {
    socketRef.current?.emit('dashboard:solicitar-snapshot', filtro);
  };

  return { snapshot, conectado, solicitarAtualizacao };
}

// Caminho: frontend/src/hooks/useCronometro.ts

import { useEffect, useState } from 'react';

/** Retorna os segundos decorridos desde `inicioISO`, atualizando a cada segundo. */
export function useCronometro(inicioISO: string | null): number {
  const [segundos, setSegundos] = useState(0);

  useEffect(() => {
    if (!inicioISO) {
      setSegundos(0);
      return;
    }

    const inicio = new Date(inicioISO).getTime();
    const atualizar = () => setSegundos(Math.max(0, Math.floor((Date.now() - inicio) / 1000)));

    atualizar();
    const intervalo = setInterval(atualizar, 1000);
    return () => clearInterval(intervalo);
  }, [inicioISO]);

  return segundos;
}

export function formatarHMS(totalSegundosEntrada: number): string {
  const totalSegundos = Math.max(0, totalSegundosEntrada);
  const h = Math.floor(totalSegundos / 3600).toString().padStart(2, '0');
  const m = Math.floor((totalSegundos % 3600) / 60).toString().padStart(2, '0');
  const s = Math.floor(totalSegundos % 60).toString().padStart(2, '0');
  return `${h}:${m}:${s}`;
}

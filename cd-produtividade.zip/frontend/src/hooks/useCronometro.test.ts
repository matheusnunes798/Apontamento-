// Caminho: frontend/src/hooks/useCronometro.test.ts

import { describe, it, expect } from 'vitest';
import { formatarHMS } from './useCronometro';

describe('formatarHMS', () => {
  it('formata zero segundos como 00:00:00', () => {
    expect(formatarHMS(0)).toBe('00:00:00');
  });

  it('formata segundos, minutos e horas corretamente', () => {
    expect(formatarHMS(3661)).toBe('01:01:01'); // 1h 1min 1s
  });

  it('preenche com zero à esquerda valores menores que 10', () => {
    expect(formatarHMS(65)).toBe('00:01:05');
  });

  it('nunca retorna negativo mesmo com entrada negativa', () => {
    expect(formatarHMS(-10)).not.toContain('-');
  });
});

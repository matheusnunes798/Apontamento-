// Caminho: frontend/src/services/api.ts

import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL
    ? `${import.meta.env.VITE_API_URL}/api/v1`
    : 'http://localhost:3333/api/v1',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

let renovacaoEmAndamento: Promise<string> | null = null;

async function renovarToken(): Promise<string> {
  const refreshToken = localStorage.getItem('refreshToken');
  if (!refreshToken) throw new Error('Sem refresh token disponível.');

  const resposta = await axios.post(
    `${api.defaults.baseURL}/auth/refresh`,
    { refreshToken },
  );

  localStorage.setItem('accessToken', resposta.data.accessToken);
  localStorage.setItem('refreshToken', resposta.data.refreshToken);
  return resposta.data.accessToken;
}

api.interceptors.response.use(
  (resposta) => resposta,
  async (erro: AxiosError) => {
    const configOriginal = erro.config as InternalAxiosRequestConfig & { _retry?: boolean };

    if (erro.response?.status === 401 && configOriginal && !configOriginal._retry) {
      configOriginal._retry = true;
      try {
        renovacaoEmAndamento = renovacaoEmAndamento ?? renovarToken();
        const novoToken = await renovacaoEmAndamento;
        renovacaoEmAndamento = null;

        if (configOriginal.headers) {
          configOriginal.headers.Authorization = `Bearer ${novoToken}`;
        }
        return api(configOriginal);
      } catch (erroRenovacao) {
        renovacaoEmAndamento = null;
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(erroRenovacao);
      }
    }

    return Promise.reject(erro);
  },
);

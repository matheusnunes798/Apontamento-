// Caminho: frontend/src/services/dominio.ts

import { api } from './api';

export type Permissao = 'ADMINISTRADOR' | 'SUPERVISOR' | 'FUNCIONARIO';

export type TipoAtividade =
  | 'SEPARACAO'
  | 'PICKING'
  | 'CONFERENCIA'
  | 'EMBALAGEM'
  | 'RECEBIMENTO'
  | 'INVENTARIO';

export interface FuncionarioLogado {
  id: string;
  nome: string;
  login: string;
  permissao: Permissao;
  setorId: string;
  cargo: string;
}

export interface RegistroAtividade {
  id: string;
  funcionarioId: string;
  tipoAtividade: TipoAtividade;
  horaInicio: string;
  horaFim: string | null;
  duracaoSegundos: number | null;
  status: 'ABERTO' | 'FINALIZADO' | 'CANCELADO';
}

export const AtividadeLabel: Record<TipoAtividade, string> = {
  SEPARACAO: 'Separação',
  PICKING: 'Picking',
  CONFERENCIA: 'Conferência',
  EMBALAGEM: 'Embalagem',
  RECEBIMENTO: 'Recebimento',
  INVENTARIO: 'Inventário',
};

export const authService = {
  async login(login: string, senha: string) {
    const { data } = await api.post('/auth/login', { login, senha });
    localStorage.setItem('accessToken', data.accessToken);
    localStorage.setItem('refreshToken', data.refreshToken);
    localStorage.setItem('funcionario', JSON.stringify(data.funcionario));
    return data.funcionario as FuncionarioLogado;
  },

  async logout() {
    const refreshToken = localStorage.getItem('refreshToken');
    if (refreshToken) {
      await api.post('/auth/logout', { refreshToken }).catch(() => undefined);
    }
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('funcionario');
  },

  usuarioAtual(): FuncionarioLogado | null {
    const bruto = localStorage.getItem('funcionario');
    return bruto ? JSON.parse(bruto) : null;
  },
};

export const atividadesService = {
  async iniciar(tipoAtividade: TipoAtividade) {
    const { data } = await api.post('/atividades/iniciar', { tipoAtividade });
    return data as RegistroAtividade;
  },

  async encerrar(
    registroId: string,
    payload: { quantidadePedidos?: number; quantidadeItens?: number; observacoes?: string },
  ) {
    const { data } = await api.patch(`/atividades/${registroId}/encerrar`, payload);
    return data as RegistroAtividade;
  },

  async emAndamento(funcionarioId: string) {
    const { data } = await api.get(`/atividades/em-andamento/${funcionarioId}`);
    return data as RegistroAtividade | null;
  },
};

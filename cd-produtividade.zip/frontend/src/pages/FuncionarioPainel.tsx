// Caminho: frontend/src/pages/FuncionarioPainel.tsx

import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { atividadesService, RegistroAtividade, TipoAtividade } from '../services/dominio';
import BotaoAtividade from '../components/BotaoAtividade';
import ModalEncerrarAtividade from '../components/ModalEncerrarAtividade';
import { useCronometro, formatarHMS } from '../hooks/useCronometro';

const ATIVIDADES: TipoAtividade[] = [
  'SEPARACAO',
  'PICKING',
  'CONFERENCIA',
  'EMBALAGEM',
  'RECEBIMENTO',
  'INVENTARIO',
];

export default function FuncionarioPainel() {
  const { usuario, sair } = useAuth();
  const [registroAtivo, setRegistroAtivo] = useState<RegistroAtividade | null>(null);
  const [carregandoInicial, setCarregandoInicial] = useState(true);
  const [processando, setProcessando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [modalAberto, setModalAberto] = useState(false);

  const segundosDecorridos = useCronometro(registroAtivo?.horaInicio ?? null);

  useEffect(() => {
    if (!usuario) return;
    atividadesService
      .emAndamento(usuario.id)
      .then((registro) => setRegistroAtivo(registro))
      .finally(() => setCarregandoInicial(false));
  }, [usuario]);

  async function aoClicarAtividade(tipo: TipoAtividade) {
    setErro(null);

    if (registroAtivo) {
      if (registroAtivo.tipoAtividade === tipo) {
        setModalAberto(true);
      }
      // Se clicou em outra atividade enquanto uma está aberta, o botão já
      // vem desabilitado (bloqueado) — nada a fazer aqui.
      return;
    }

    setProcessando(true);
    try {
      const registro = await atividadesService.iniciar(tipo);
      setRegistroAtivo(registro);
    } catch (e: any) {
      setErro(e?.response?.data?.mensagem ?? 'Não foi possível iniciar a atividade.');
    } finally {
      setProcessando(false);
    }
  }

  async function aoConfirmarEncerramento(dados: {
    quantidadePedidos: number;
    quantidadeItens: number;
    observacoes: string;
  }) {
    if (!registroAtivo) return;
    setProcessando(true);
    try {
      await atividadesService.encerrar(registroAtivo.id, dados);
      setRegistroAtivo(null);
      setModalAberto(false);
    } catch (e: any) {
      setErro(e?.response?.data?.mensagem ?? 'Não foi possível encerrar a atividade.');
    } finally {
      setProcessando(false);
    }
  }

  if (carregandoInicial) {
    return (
      <div className="min-h-screen flex items-center justify-center text-texto-muted font-mono">
        Carregando...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-base pb-16">
      <header className="border-b border-borda px-5 py-4 flex items-center justify-between sticky top-0 bg-base/90 backdrop-blur z-10">
        <div>
          <p className="font-display font-bold text-lg leading-tight">{usuario?.nome}</p>
          <p className="text-xs text-texto-muted font-mono">{usuario?.cargo}</p>
        </div>
        <button onClick={sair} className="foco-visivel text-sm text-texto-muted underline">
          Sair
        </button>
      </header>

      {registroAtivo && (
        <div className="mx-5 mt-5 rounded-2xl border border-operacao bg-operacao/10 p-5 text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-operacao mb-1">
            Em andamento
          </p>
          <p className="font-mono text-4xl font-bold text-texto">{formatarHMS(segundosDecorridos)}</p>
        </div>
      )}

      {erro && (
        <p className="mx-5 mt-4 text-sm text-encerrar font-medium" role="alert">
          {erro}
        </p>
      )}

      <main className="px-5 mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
        {ATIVIDADES.map((tipo) => (
          <BotaoAtividade
            key={tipo}
            tipo={tipo}
            emAndamento={registroAtivo?.tipoAtividade === tipo}
            bloqueado={processando || (!!registroAtivo && registroAtivo.tipoAtividade !== tipo)}
            aoClicar={() => aoClicarAtividade(tipo)}
          />
        ))}
      </main>

      {modalAberto && registroAtivo && (
        <ModalEncerrarAtividade
          tipo={registroAtivo.tipoAtividade}
          segundosDecorridos={segundosDecorridos}
          aoConfirmar={aoConfirmarEncerramento}
          aoCancelar={() => setModalAberto(false)}
        />
      )}
    </div>
  );
}

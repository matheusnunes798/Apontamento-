// Caminho: frontend/src/pages/Login.tsx

import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const { entrar, carregando, erro } = useAuth();
  const [login, setLogin] = useState('');
  const [senha, setSenha] = useState('');
  const navigate = useNavigate();

  async function aoEnviar(e: FormEvent) {
    e.preventDefault();
    try {
      await entrar(login, senha);
      navigate('/');
    } catch {
      // erro já fica exposto via contexto (useAuth().erro)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-base px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 mb-2">
            <span className="h-2.5 w-2.5 rounded-full bg-operacao" />
            <span className="font-mono text-xs tracking-widest text-texto-muted uppercase">
              Sistema operacional
            </span>
          </div>
          <h1 className="font-display text-3xl font-bold text-texto">Produtividade CD</h1>
        </div>

        <form
          onSubmit={aoEnviar}
          className="bg-painel border border-borda rounded-2xl p-6 shadow-painel"
        >
          <label className="block mb-4">
            <span className="block text-sm text-texto-muted mb-1.5">Login</span>
            <input
              autoFocus
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              className="foco-visivel w-full rounded-xl bg-painel-alt border border-borda px-4 py-3 text-lg text-texto"
              placeholder="ex: joao.silva"
              autoComplete="username"
            />
          </label>

          <label className="block mb-6">
            <span className="block text-sm text-texto-muted mb-1.5">Senha</span>
            <input
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              className="foco-visivel w-full rounded-xl bg-painel-alt border border-borda px-4 py-3 text-lg text-texto"
              placeholder="••••••••"
              autoComplete="current-password"
            />
          </label>

          {erro && (
            <p className="mb-4 text-sm text-encerrar font-medium" role="alert">
              {erro}
            </p>
          )}

          <button
            type="submit"
            disabled={carregando}
            className="foco-visivel w-full rounded-xl bg-info hover:brightness-110 disabled:opacity-50 text-base font-semibold py-3.5 text-white transition"
          >
            {carregando ? 'Entrando...' : 'Entrar'}
          </button>
        </form>
      </div>
    </div>
  );
}

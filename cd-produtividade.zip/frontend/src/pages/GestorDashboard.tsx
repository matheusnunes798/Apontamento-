// Caminho: frontend/src/pages/GestorDashboard.tsx

import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useDashboardSocket } from '../hooks/useDashboardSocket';
import { formatarHMS } from '../hooks/useCronometro';
import { AtividadeLabel, TipoAtividade } from '../services/dominio';
import CartaoIndicador from '../components/CartaoIndicador';

export default function GestorDashboard() {
  const { usuario, sair } = useAuth();
  const [filtro] = useState({});
  const { snapshot, conectado } = useDashboardSocket(filtro);

  return (
    <div className="min-h-screen bg-base pb-16">
      <header className="border-b border-borda px-6 py-4 flex items-center justify-between sticky top-0 bg-base/90 backdrop-blur z-10">
        <div>
          <h1 className="font-display font-bold text-xl">Painel do Gestor</h1>
          <p className="text-xs text-texto-muted font-mono flex items-center gap-1.5 mt-0.5">
            <span className={`h-1.5 w-1.5 rounded-full ${conectado ? 'bg-operacao' : 'bg-encerrar'}`} />
            {conectado ? 'Conectado em tempo real' : 'Reconectando...'}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-texto-muted">{usuario?.nome}</span>
          <button onClick={sair} className="foco-visivel text-sm text-texto-muted underline">
            Sair
          </button>
        </div>
      </header>

      {!snapshot ? (
        <p className="text-center text-texto-muted font-mono mt-16">Carregando dados...</p>
      ) : (
        <main className="px-6 mt-6 max-w-6xl mx-auto space-y-8">
          <section className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <CartaoIndicador rotulo="Ativos agora" valor={snapshot.funcionariosAtivos} destaque="operacao" />
            <CartaoIndicador rotulo="Parados" valor={snapshot.funcionariosParados} destaque="ocioso" />
            <CartaoIndicador rotulo="Pedidos concluídos hoje" valor={snapshot.resumoAtividades.pedidosConcluidos} />
            <CartaoIndicador rotulo="Itens processados hoje" valor={snapshot.resumoAtividades.itensProcessados} />
            <CartaoIndicador rotulo="Pedidos/hora" valor={snapshot.resumoAtividades.pedidosPorHora} destaque="info" />
            <CartaoIndicador rotulo="Itens/hora" valor={snapshot.resumoAtividades.itensPorHora} destaque="info" />
            <CartaoIndicador
              rotulo="Tempo médio/atividade"
              valor={formatarHMS(snapshot.resumoAtividades.tempoMedioPorAtividadeSegundos)}
            />
            <CartaoIndicador
              rotulo="Tempo médio/pedido"
              valor={formatarHMS(snapshot.resumoAtividades.tempoMedioPorPedidoSegundos)}
            />
          </section>

          <section>
            <h2 className="font-display font-bold text-lg mb-3">Trabalhando agora</h2>
            {snapshot.emAndamento.length === 0 ? (
              <p className="text-texto-muted text-sm">Ninguém com atividade em aberto no momento.</p>
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-borda">
                <table className="w-full text-sm">
                  <thead className="bg-painel-alt text-texto-muted font-mono text-xs uppercase">
                    <tr>
                      <th className="text-left px-4 py-3">Funcionário</th>
                      <th className="text-left px-4 py-3">Atividade</th>
                      <th className="text-right px-4 py-3">Tempo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {snapshot.emAndamento.map((f) => (
                      <tr key={f.funcionarioId} className="border-t border-borda">
                        <td className="px-4 py-3">
                          <p className="font-medium">{f.nome}</p>
                          <p className="text-xs text-texto-muted font-mono">{f.matricula}</p>
                        </td>
                        <td className="px-4 py-3">
                          {AtividadeLabel[f.atividade as TipoAtividade] ?? f.atividade}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-operacao">
                          {formatarHMS(f.segundosEmAndamento)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section>
            <h2 className="font-display font-bold text-lg mb-3">Sem atividade</h2>
            {snapshot.parados.length === 0 ? (
              <p className="text-texto-muted text-sm">Todos os funcionários ativos estão em atividade.</p>
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-borda">
                <table className="w-full text-sm">
                  <thead className="bg-painel-alt text-texto-muted font-mono text-xs uppercase">
                    <tr>
                      <th className="text-left px-4 py-3">Funcionário</th>
                      <th className="text-right px-4 py-3">Parado há</th>
                    </tr>
                  </thead>
                  <tbody>
                    {snapshot.parados.map((f) => (
                      <tr key={f.funcionarioId} className="border-t border-borda">
                        <td className="px-4 py-3">
                          <p className="font-medium">{f.nome}</p>
                          <p className="text-xs text-texto-muted font-mono">{f.matricula}</p>
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-ocioso">
                          {f.segundosParado !== null ? formatarHMS(f.segundosParado) : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <section className="grid md:grid-cols-2 gap-6">
            <div>
              <h2 className="font-display font-bold text-lg mb-3">Ranking de produtividade</h2>
              <ol className="space-y-2">
                {snapshot.ranking.produtividade.map((r, i) => (
                  <li
                    key={r.funcionarioId}
                    className="flex items-center justify-between rounded-xl bg-painel border border-borda px-4 py-3"
                  >
                    <span className="flex items-center gap-3">
                      <span className="font-mono text-texto-muted text-sm w-5">{i + 1}º</span>
                      <span className="font-medium">{r.nome}</span>
                    </span>
                    <span className="font-mono text-operacao">{r.pedidosPorHora} pedidos/h</span>
                  </li>
                ))}
              </ol>
            </div>

            <div>
              <h2 className="font-display font-bold text-lg mb-3">Maior tempo ocioso</h2>
              <ol className="space-y-2">
                {snapshot.ranking.tempoOcioso.map((r, i) => (
                  <li
                    key={r.funcionarioId}
                    className="flex items-center justify-between rounded-xl bg-painel border border-borda px-4 py-3"
                  >
                    <span className="flex items-center gap-3">
                      <span className="font-mono text-texto-muted text-sm w-5">{i + 1}º</span>
                      <span className="font-medium">{r.nome}</span>
                    </span>
                    <span className="font-mono text-ocioso">{formatarHMS(r.segundos)}</span>
                  </li>
                ))}
              </ol>
            </div>
          </section>
        </main>
      )}
    </div>
  );
}

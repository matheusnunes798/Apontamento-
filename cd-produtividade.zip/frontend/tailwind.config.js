// Caminho: frontend/tailwind.config.js
//
// TOKENS DE DESIGN — "Painel de Controle Operacional"
// Referência visual: quadros de status de centros de distribuição / torres de
// controle — alto contraste, cor com significado operacional (não decorativa),
// tipografia técnica. Evita o clichê de fundo creme+serif ou verde-ácido genérico:
// aqui a cor central é o VERDE-OPERAÇÃO (funcionário trabalhando) vs
// ÂMBAR-OCIOSO vs VERMELHO-ENCERRAR, porque é literalmente o vocabulário do CD.

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        base: '#10141B',
        painel: '#1A2029',
        'painel-alt': '#232B37',
        borda: '#2E3844',
        texto: '#EDF1F7',
        'texto-muted': '#8A97A8',
        operacao: '#2FBF71',
        ocioso: '#F0A63A',
        encerrar: '#E5484D',
        info: '#4C9FFE',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        painel: '0 1px 0 0 rgba(255,255,255,0.04) inset, 0 8px 24px -8px rgba(0,0,0,0.5)',
      },
    },
  },
  plugins: [],
};

-- Caminho: backend/prisma/migrations/00000000000000_constraint_atividade_unica/migration.sql
--
-- Garante, no nível de banco de dados, que um funcionário nunca tenha mais
-- de um registro de atividade com status ABERTO ao mesmo tempo.
-- Isso é uma camada extra de segurança além da validação feita no service
-- (nunca confiar só na aplicação para uma invariante crítica de negócio).

CREATE UNIQUE INDEX idx_uma_atividade_aberta_por_funcionario
ON registros_atividade ("funcionarioId")
WHERE status = 'ABERTO';

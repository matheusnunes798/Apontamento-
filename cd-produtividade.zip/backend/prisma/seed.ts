// Caminho: backend/prisma/seed.ts

import { PrismaClient, Permissao } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('Iniciando seed...');

  const setorRecebimento = await prisma.setor.upsert({
    where: { nome: 'Recebimento' },
    update: {},
    create: { nome: 'Recebimento' },
  });

  const setorExpedicao = await prisma.setor.upsert({
    where: { nome: 'Expedição' },
    update: {},
    create: { nome: 'Expedição' },
  });

  await prisma.setor.upsert({
    where: { nome: 'Armazenagem' },
    update: {},
    create: { nome: 'Armazenagem' },
  });

  await prisma.turno.upsert({
    where: { nome: 'Manhã' },
    update: {},
    create: { nome: 'Manhã', horaInicio: '06:00', horaFim: '14:00' },
  });

  await prisma.turno.upsert({
    where: { nome: 'Tarde' },
    update: {},
    create: { nome: 'Tarde', horaInicio: '14:00', horaFim: '22:00' },
  });

  await prisma.turno.upsert({
    where: { nome: 'Noite' },
    update: {},
    create: { nome: 'Noite', horaInicio: '22:00', horaFim: '06:00' },
  });

  const equipeExpedicaoA = await prisma.equipe.upsert({
    where: { nome_setorId: { nome: 'Equipe A', setorId: setorExpedicao.id } },
    update: {},
    create: { nome: 'Equipe A', setorId: setorExpedicao.id },
  });

  const senhaAdminHash = await bcrypt.hash('admin123', 10);
  await prisma.funcionario.upsert({
    where: { login: 'admin' },
    update: {},
    create: {
      nome: 'Administrador do Sistema',
      matricula: '000001',
      cargo: 'Administrador',
      login: 'admin',
      senhaHash: senhaAdminHash,
      permissao: Permissao.ADMINISTRADOR,
      setorId: setorRecebimento.id,
    },
  });

  const senhaFuncHash = await bcrypt.hash('operador123', 10);
  await prisma.funcionario.upsert({
    where: { login: 'joao.silva' },
    update: {},
    create: {
      nome: 'João Silva',
      matricula: '000002',
      cargo: 'Operador de Empilhadeira',
      login: 'joao.silva',
      senhaHash: senhaFuncHash,
      permissao: Permissao.FUNCIONARIO,
      setorId: setorExpedicao.id,
      equipeId: equipeExpedicaoA.id,
    },
  });

  console.log('Seed concluído.');
  console.log('Login admin -> usuário: admin / senha: admin123 (troque em produção)');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

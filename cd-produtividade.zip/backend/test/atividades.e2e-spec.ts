// Caminho: backend/test/atividades.e2e-spec.ts
//
// PRÉ-REQUISITO: este teste sobe a aplicação NestJS completa e conversa
// com um banco Postgres real (não mockado), para validar de ponta a ponta
// a regra de negócio mais crítica do sistema: nunca permitir duas
// atividades abertas para o mesmo funcionário — inclusive sob concorrência.
//
// Antes de rodar:
//   1. Suba um Postgres de teste (ex.: docker run -p 5433:5432 ... postgres:16-alpine)
//   2. Configure DATABASE_URL apontando para ele (ex.: em backend/.env.test)
//   3. Rode as migrations: npx prisma migrate deploy
//   4. Rode: npm run test:e2e

import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/infra/prisma/prisma.service';

describe('Fluxo de Atividades (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let tokenFuncionario: string;
  let funcionarioId: string;

  beforeAll(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
    app.setGlobalPrefix('api/v1');
    await app.init();

    prisma = app.get(PrismaService);

    // Cria um setor e um funcionário isolados para este teste
    const setor = await prisma.setor.create({ data: { nome: `Setor Teste E2E ${Date.now()}` } });
    const bcrypt = await import('bcrypt');
    const funcionario = await prisma.funcionario.create({
      data: {
        nome: 'Funcionário Teste E2E',
        matricula: `E2E-${Date.now()}`,
        cargo: 'Operador',
        login: `e2e.${Date.now()}`,
        senhaHash: await bcrypt.hash('senha123', 10),
        permissao: 'FUNCIONARIO',
        setorId: setor.id,
      },
    });
    funcionarioId = funcionario.id;

    const respostaLogin = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ login: funcionario.login, senha: 'senha123' });

    tokenFuncionario = respostaLogin.body.accessToken;
  });

  afterAll(async () => {
    await prisma.registroAtividade.deleteMany({ where: { funcionarioId } });
    await prisma.funcionario.delete({ where: { id: funcionarioId } });
    await app.close();
  });

  it('deve iniciar uma atividade com sucesso', async () => {
    const resposta = await request(app.getHttpServer())
      .post('/api/v1/atividades/iniciar')
      .set('Authorization', `Bearer ${tokenFuncionario}`)
      .send({ tipoAtividade: 'SEPARACAO' });

    expect(resposta.status).toBe(201);
    expect(resposta.body.status).toBe('ABERTO');
  });

  it('deve impedir iniciar uma segunda atividade enquanto a primeira está aberta', async () => {
    const resposta = await request(app.getHttpServer())
      .post('/api/v1/atividades/iniciar')
      .set('Authorization', `Bearer ${tokenFuncionario}`)
      .send({ tipoAtividade: 'PICKING' });

    expect(resposta.status).toBe(409);
  });

  it('não deve permitir duas atividades abertas mesmo com requests simultâneos (condição de corrida)', async () => {
    // Encerra a atividade da etapa anterior para reiniciar o cenário
    const emAndamento = await request(app.getHttpServer())
      .get(`/api/v1/atividades/em-andamento/${funcionarioId}`)
      .set('Authorization', `Bearer ${tokenFuncionario}`);

    await request(app.getHttpServer())
      .patch(`/api/v1/atividades/${emAndamento.body.id}/encerrar`)
      .set('Authorization', `Bearer ${tokenFuncionario}`)
      .send({});

    // Dispara duas iniciações em paralelo — apenas uma deve ter sucesso (201)
    const [respostaA, respostaB] = await Promise.all([
      request(app.getHttpServer())
        .post('/api/v1/atividades/iniciar')
        .set('Authorization', `Bearer ${tokenFuncionario}`)
        .send({ tipoAtividade: 'CONFERENCIA' }),
      request(app.getHttpServer())
        .post('/api/v1/atividades/iniciar')
        .set('Authorization', `Bearer ${tokenFuncionario}`)
        .send({ tipoAtividade: 'EMBALAGEM' }),
    ]);

    const statusCodes = [respostaA.status, respostaB.status].sort();
    expect(statusCodes).toEqual([201, 409]);
  });
});

// Caminho: backend/src/common/decorators/current-user.decorator.ts

import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface UsuarioAutenticado {
  id: string;
  login: string;
  permissao: string;
  setorId: string;
}

/**
 * Extrai o usuário autenticado (populado pelo JwtStrategy) da requisição.
 * Uso: @CurrentUser() usuario: UsuarioAutenticado
 */
export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): UsuarioAutenticado => {
    const request = ctx.switchToHttp().getRequest();
    return request.user;
  },
);

// Caminho: backend/src/common/decorators/roles.decorator.ts

import { SetMetadata } from '@nestjs/common';
import { Permissao } from '@prisma/client';

export const ROLES_KEY = 'roles';

/**
 * Marca um endpoint com as permissões que podem acessá-lo.
 * Uso: @Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
 */
export const Roles = (...roles: Permissao[]) => SetMetadata(ROLES_KEY, roles);

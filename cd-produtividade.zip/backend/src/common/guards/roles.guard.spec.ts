// Caminho: backend/src/common/guards/roles.guard.spec.ts

import { ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { RolesGuard } from './roles.guard';

function criarContextoFalso(user: any) {
  return {
    getHandler: () => ({}),
    getClass: () => ({}),
    switchToHttp: () => ({ getRequest: () => ({ user }) }),
  } as any;
}

describe('RolesGuard', () => {
  it('permite acesso quando o endpoint não declara @Roles', () => {
    const reflector = { getAllAndOverride: jest.fn().mockReturnValue(undefined) } as unknown as Reflector;
    const guard = new RolesGuard(reflector);

    expect(guard.canActivate(criarContextoFalso({ permissao: 'FUNCIONARIO' }))).toBe(true);
  });

  it('permite acesso quando a permissão do usuário está na lista exigida', () => {
    const reflector = {
      getAllAndOverride: jest.fn().mockReturnValue(['ADMINISTRADOR', 'SUPERVISOR']),
    } as unknown as Reflector;
    const guard = new RolesGuard(reflector);

    expect(guard.canActivate(criarContextoFalso({ permissao: 'SUPERVISOR' }))).toBe(true);
  });

  it('bloqueia acesso quando a permissão do usuário não está na lista exigida', () => {
    const reflector = {
      getAllAndOverride: jest.fn().mockReturnValue(['ADMINISTRADOR']),
    } as unknown as Reflector;
    const guard = new RolesGuard(reflector);

    expect(() => guard.canActivate(criarContextoFalso({ permissao: 'FUNCIONARIO' }))).toThrow(
      ForbiddenException,
    );
  });
});

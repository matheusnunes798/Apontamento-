// Caminho: backend/src/app.module.ts

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { PrismaModule } from './infra/prisma/prisma.module';
import { AuthModule } from './modules/auth/auth.module';
import { FuncionariosModule } from './modules/funcionarios/funcionarios.module';
import { AtividadesModule } from './modules/atividades/atividades.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { RelatoriosModule } from './modules/relatorios/relatorios.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    EventEmitterModule.forRoot(),
    PrismaModule,
    AuthModule,
    FuncionariosModule,
    AtividadesModule,
    DashboardModule,
    RelatoriosModule,
  ],
})
export class AppModule {}

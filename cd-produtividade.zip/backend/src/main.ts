// Caminho: backend/src/main.ts

import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './common/filters/http-exception.filter';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap');

  app.use(helmet());

  app.enableCors({
    origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173',
    credentials: true,
  });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // remove campos não esperados no DTO
      forbidNonWhitelisted: true, // rejeita payload com campos desconhecidos
      transform: true, // converte payload para a classe do DTO automaticamente
      errorHttpStatusCode: 422,
    }),
  );

  app.useGlobalFilters(new HttpExceptionFilter());

  app.setGlobalPrefix('api/v1');

  const configSwagger = new DocumentBuilder()
    .setTitle('API — Produtividade Operacional CD')
    .setDescription(
      'Endpoints para controle de atividades operacionais, dashboard em tempo real e relatórios.',
    )
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  const documentoSwagger = SwaggerModule.createDocument(app, configSwagger);
  SwaggerModule.setup('api/docs', app, documentoSwagger);

  const port = process.env.PORT ?? 3333;
  await app.listen(port);
  logger.log(`API rodando em http://localhost:${port}/api/v1`);
  logger.log(`Documentação Swagger em http://localhost:${port}/api/docs`);
}

bootstrap();

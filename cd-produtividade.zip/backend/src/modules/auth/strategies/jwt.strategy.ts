// Caminho: backend/src/modules/auth/strategies/jwt.strategy.ts

import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../../infra/prisma/prisma.service';

export interface JwtPayload {
  sub: string; // id do funcionário
  login: string;
  permissao: string;
  setorId: string;
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.get<string>('JWT_SECRET'),
    });
  }

  async validate(payload: JwtPayload) {
    const funcionario = await this.prisma.funcionario.findUnique({
      where: { id: payload.sub },
      select: { id: true, login: true, permissao: true, setorId: true, ativo: true },
    });

    if (!funcionario || !funcionario.ativo) {
      throw new UnauthorizedException('Usuário inválido ou inativo.');
    }

    // Isso é anexado a request.user e usado pelo @CurrentUser() / RolesGuard
    return {
      id: funcionario.id,
      login: funcionario.login,
      permissao: funcionario.permissao,
      setorId: funcionario.setorId,
    };
  }
}

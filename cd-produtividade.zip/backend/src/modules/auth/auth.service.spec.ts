// Caminho: backend/src/modules/auth/auth.service.spec.ts

import { UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;
  let prismaMock: any;
  let jwtServiceMock: any;
  let configServiceMock: any;

  const senhaPlana = 'senha123';
  let senhaHash: string;

  beforeAll(async () => {
    senhaHash = await bcrypt.hash(senhaPlana, 10);
  });

  beforeEach(() => {
    prismaMock = {
      funcionario: { findUnique: jest.fn() },
      logAuditoria: { create: jest.fn() },
      refreshToken: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), updateMany: jest.fn() },
    };
    jwtServiceMock = { signAsync: jest.fn().mockResolvedValue('token-jwt-falso') };
    configServiceMock = { get: jest.fn().mockReturnValue('valor-qualquer') };
    service = new AuthService(prismaMock, jwtServiceMock, configServiceMock);
  });

  it('deve rejeitar login com usuário inexistente', async () => {
    prismaMock.funcionario.findUnique.mockResolvedValue(null);

    await expect(service.login({ login: 'ninguem', senha: senhaPlana })).rejects.toThrow(
      UnauthorizedException,
    );
    expect(prismaMock.logAuditoria.create).toHaveBeenCalled();
  });

  it('deve rejeitar login com senha incorreta', async () => {
    prismaMock.funcionario.findUnique.mockResolvedValue({
      id: 'func-1',
      login: 'joao.silva',
      senhaHash,
      ativo: true,
    });

    await expect(
      service.login({ login: 'joao.silva', senha: 'senha-errada' }),
    ).rejects.toThrow(UnauthorizedException);
  });

  it('deve rejeitar login de funcionário inativo mesmo com senha correta', async () => {
    prismaMock.funcionario.findUnique.mockResolvedValue({
      id: 'func-1',
      login: 'joao.silva',
      senhaHash,
      ativo: false,
    });

    await expect(service.login({ login: 'joao.silva', senha: senhaPlana })).rejects.toThrow(
      UnauthorizedException,
    );
  });

  it('deve autenticar com sucesso e gerar tokens quando credenciais são válidas', async () => {
    prismaMock.funcionario.findUnique.mockResolvedValue({
      id: 'func-1',
      nome: 'João Silva',
      login: 'joao.silva',
      senhaHash,
      ativo: true,
      permissao: 'FUNCIONARIO',
      setorId: 'setor-1',
      cargo: 'Operador',
    });
    prismaMock.refreshToken.create.mockResolvedValue({});

    const resultado = await service.login({ login: 'joao.silva', senha: senhaPlana });

    expect(resultado.accessToken).toBe('token-jwt-falso');
    expect(resultado.refreshToken).toBeDefined();
    expect(resultado.funcionario.login).toBe('joao.silva');
    expect(prismaMock.logAuditoria.create).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ acao: 'LOGIN' }) }),
    );
  });

  it('deve rejeitar refresh token expirado', async () => {
    prismaMock.refreshToken.findUnique.mockResolvedValue({
      id: 'rt-1',
      revogado: false,
      expiraEm: new Date(Date.now() - 1000),
      funcionario: {},
    });

    await expect(service.refresh('token-expirado')).rejects.toThrow(UnauthorizedException);
  });
});

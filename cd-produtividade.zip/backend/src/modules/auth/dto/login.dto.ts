// Caminho: backend/src/modules/auth/dto/login.dto.ts

import { IsNotEmpty, IsString, MinLength } from 'class-validator';

export class LoginDto {
  @IsString()
  @IsNotEmpty({ message: 'O login é obrigatório.' })
  login: string;

  @IsString()
  @MinLength(4, { message: 'A senha deve ter ao menos 4 caracteres.' })
  senha: string;
}

// Caminho: backend/src/modules/auth/auth.service.ts

import {
  Injectable,
  UnauthorizedException,
  Inject,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../infra/prisma/prisma.service';
import { LoginDto } from './dto/login.dto';
import { AcaoAuditoria } from '@prisma/client';

interface TokensResponse {
  accessToken: string;
  refreshToken: string;
  funcionario: {
    id: string;
    nome: string;
    login: string;
    permissao: string;
    setorId: string;
    cargo: string;
  };
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async login(dto: LoginDto, ip?: string): Promise<TokensResponse> {
    const funcionario = await this.prisma.funcionario.findUnique({
      where: { login: dto.login },
    });

    const senhaConfere = funcionario
      ? await bcrypt.compare(dto.senha, funcionario.senhaHash)
      : false;

    if (!funcionario || !funcionario.ativo || !senhaConfere) {
      // Log de tentativa falha, sem expor qual campo estava errado
      await this.prisma.logAuditoria.create({
        data: {
          acao: AcaoAuditoria.LOGIN_FALHO,
          entidade: 'Funcionario',
          entidadeId: funcionario?.id,
          ip,
          dadosDepois: { loginTentado: dto.login },
        },
      });
      throw new UnauthorizedException('Login ou senha inválidos.');
    }

    const tokens = await this.gerarTokens(funcionario);

    await this.prisma.logAuditoria.create({
      data: {
        funcionarioId: funcionario.id,
        acao: AcaoAuditoria.LOGIN,
        entidade: 'Funcionario',
        entidadeId: funcionario.id,
        ip,
      },
    });

    return {
      ...tokens,
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        login: funcionario.login,
        permissao: funcionario.permissao,
        setorId: funcionario.setorId,
        cargo: funcionario.cargo,
      },
    };
  }

  async refresh(refreshTokenValue: string): Promise<{ accessToken: string; refreshToken: string }> {
    const registro = await this.prisma.refreshToken.findUnique({
      where: { token: refreshTokenValue },
      include: { funcionario: true },
    });

    if (!registro || registro.revogado || registro.expiraEm < new Date()) {
      throw new UnauthorizedException('Refresh token inválido ou expirado.');
    }

    // Revoga o token usado (rotação de refresh token — boa prática de segurança)
    await this.prisma.refreshToken.update({
      where: { id: registro.id },
      data: { revogado: true },
    });

    const tokens = await this.gerarTokens(registro.funcionario);
    return tokens;
  }

  async logout(refreshTokenValue: string): Promise<void> {
    await this.prisma.refreshToken.updateMany({
      where: { token: refreshTokenValue },
      data: { revogado: true },
    });
  }

  private async gerarTokens(funcionario: {
    id: string;
    login: string;
    permissao: string;
    setorId: string;
  }): Promise<{ accessToken: string; refreshToken: string }> {
    const payload = {
      sub: funcionario.id,
      login: funcionario.login,
      permissao: funcionario.permissao,
      setorId: funcionario.setorId,
    };

    const accessToken = await this.jwtService.signAsync(payload, {
      secret: this.configService.get<string>('JWT_SECRET'),
      expiresIn: this.configService.get<string>('JWT_EXPIRES_IN') ?? '15m',
    });

    const refreshTokenValue = randomBytes(48).toString('hex');
    const diasExpiracao = 7;
    const expiraEm = new Date();
    expiraEm.setDate(expiraEm.getDate() + diasExpiracao);

    await this.prisma.refreshToken.create({
      data: {
        token: refreshTokenValue,
        funcionarioId: funcionario.id,
        expiraEm,
      },
    });

    return { accessToken, refreshToken: refreshTokenValue };
  }
}

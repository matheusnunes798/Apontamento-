// Caminho: backend/src/modules/relatorios/relatorios.service.spec.ts

import { BadRequestException } from '@nestjs/common';
import { RelatoriosService } from './relatorios.service';
import { TipoPeriodo } from './dto/periodo-relatorio.dto';

describe('RelatoriosService.resolverIntervalo', () => {
  let service: RelatoriosService;

  beforeEach(() => {
    service = new RelatoriosService({} as any);
  });

  it('período diário cobre do início ao fim do dia atual', () => {
    const { inicio, fim } = service.resolverIntervalo({ tipo: TipoPeriodo.DIARIO });
    expect(inicio.getHours()).toBe(0);
    expect(fim.getHours()).toBe(23);
    expect(inicio.toDateString()).toBe(fim.toDateString());
  });

  it('período semanal cobre exatamente 7 dias', () => {
    const { inicio, fim } = service.resolverIntervalo({ tipo: TipoPeriodo.SEMANAL });
    const diffDias = Math.round((fim.getTime() - inicio.getTime()) / (1000 * 60 * 60 * 24));
    expect(diffDias).toBe(6); // 7 dias inclusive (domingo a sábado)
  });

  it('período personalizado exige dataInicio e dataFim', () => {
    expect(() =>
      service.resolverIntervalo({ tipo: TipoPeriodo.PERSONALIZADO }),
    ).toThrow(BadRequestException);
  });

  it('período personalizado rejeita dataInicio posterior a dataFim', () => {
    expect(() =>
      service.resolverIntervalo({
        tipo: TipoPeriodo.PERSONALIZADO,
        dataInicio: '2026-02-10',
        dataFim: '2026-02-01',
      }),
    ).toThrow(BadRequestException);
  });

  it('período personalizado válido retorna o intervalo correto', () => {
    const { inicio, fim } = service.resolverIntervalo({
      tipo: TipoPeriodo.PERSONALIZADO,
      dataInicio: '2026-02-01',
      dataFim: '2026-02-05',
    });
    expect(inicio.getDate()).toBe(1);
    expect(fim.getDate()).toBe(5);
  });
});

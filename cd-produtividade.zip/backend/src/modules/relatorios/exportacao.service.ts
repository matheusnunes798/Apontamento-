// Caminho: backend/src/modules/relatorios/exportacao.service.ts

import { Injectable } from '@nestjs/common';
import * as ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import { RelatorioFuncionario } from './relatorios.service';

function formatarDuracao(segundos: number): string {
  const h = Math.floor(segundos / 3600);
  const m = Math.floor((segundos % 3600) / 60);
  return `${h}h ${m}min`;
}

@Injectable()
export class ExportacaoService {
  async paraExcel(relatorio: RelatorioFuncionario): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Sistema de Produtividade CD';

    const resumo = workbook.addWorksheet('Resumo');
    resumo.columns = [
      { header: 'Indicador', key: 'indicador', width: 35 },
      { header: 'Valor', key: 'valor', width: 25 },
    ];
    resumo.addRows([
      { indicador: 'Funcionário', valor: relatorio.funcionario.nome },
      { indicador: 'Matrícula', valor: relatorio.funcionario.matricula },
      { indicador: 'Cargo', valor: relatorio.funcionario.cargo },
      { indicador: 'Período', valor: `${relatorio.periodo.inicio.toLocaleDateString('pt-BR')} a ${relatorio.periodo.fim.toLocaleDateString('pt-BR')}` },
      { indicador: 'Tempo total trabalhado', valor: formatarDuracao(relatorio.tempoTotalTrabalhadoSegundos) },
      { indicador: 'Tempo ocioso', valor: formatarDuracao(relatorio.tempoOciosoSegundos) },
      { indicador: 'Quantidade de pedidos', valor: relatorio.quantidadePedidos },
      { indicador: 'Quantidade de itens', valor: relatorio.quantidadeItens },
      { indicador: 'Tempo médio por pedido', valor: formatarDuracao(relatorio.tempoMedioPorPedidoSegundos) },
      { indicador: 'Pedidos por hora', valor: relatorio.pedidosPorHora },
      { indicador: 'Itens por hora', valor: relatorio.itensPorHora },
      { indicador: 'Eficiência (%)', valor: relatorio.eficienciaPercentual },
      { indicador: 'Aproveitamento da jornada (%)', valor: relatorio.aproveitamentoJornadaPercentual },
    ]);
    resumo.getRow(1).font = { bold: true };

    const porAtividade = workbook.addWorksheet('Tempo por Atividade');
    porAtividade.columns = [
      { header: 'Atividade', key: 'atividade', width: 25 },
      { header: 'Tempo total', key: 'tempo', width: 20 },
    ];
    for (const [atividade, segundos] of Object.entries(relatorio.tempoPorAtividade)) {
      porAtividade.addRow({ atividade, tempo: formatarDuracao(segundos) });
    }
    porAtividade.getRow(1).font = { bold: true };

    const historico = workbook.addWorksheet('Histórico');
    historico.columns = [
      { header: 'Atividade', key: 'atividade', width: 18 },
      { header: 'Início', key: 'inicio', width: 20 },
      { header: 'Fim', key: 'fim', width: 20 },
      { header: 'Duração', key: 'duracao', width: 15 },
      { header: 'Pedidos', key: 'pedidos', width: 10 },
      { header: 'Itens', key: 'itens', width: 10 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Observações', key: 'obs', width: 30 },
    ];
    for (const h of relatorio.historico) {
      historico.addRow({
        atividade: h.tipoAtividade,
        inicio: new Date(h.horaInicio).toLocaleString('pt-BR'),
        fim: h.horaFim ? new Date(h.horaFim).toLocaleString('pt-BR') : '-',
        duracao: h.duracaoSegundos ? formatarDuracao(h.duracaoSegundos) : '-',
        pedidos: h.quantidadePedidos ?? 0,
        itens: h.quantidadeItens ?? 0,
        status: h.status,
        obs: h.observacoes ?? '',
      });
    }
    historico.getRow(1).font = { bold: true };

    const buffer = await workbook.xlsx.writeBuffer();
    return Buffer.from(buffer);
  }

  async paraPdf(relatorio: RelatorioFuncionario): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ margin: 40 });
      const chunks: Buffer[] = [];

      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      doc.fontSize(18).text('Relatório de Produtividade', { align: 'center' });
      doc.moveDown();

      doc.fontSize(12).text(`Funcionário: ${relatorio.funcionario.nome}`);
      doc.text(`Matrícula: ${relatorio.funcionario.matricula}`);
      doc.text(`Cargo: ${relatorio.funcionario.cargo}`);
      doc.text(
        `Período: ${relatorio.periodo.inicio.toLocaleDateString('pt-BR')} a ${relatorio.periodo.fim.toLocaleDateString('pt-BR')}`,
      );
      doc.moveDown();

      doc.fontSize(14).text('Resumo', { underline: true });
      doc.fontSize(11);
      doc.text(`Tempo total trabalhado: ${formatarDuracao(relatorio.tempoTotalTrabalhadoSegundos)}`);
      doc.text(`Tempo ocioso: ${formatarDuracao(relatorio.tempoOciosoSegundos)}`);
      doc.text(`Pedidos processados: ${relatorio.quantidadePedidos}`);
      doc.text(`Itens processados: ${relatorio.quantidadeItens}`);
      doc.text(`Tempo médio por pedido: ${formatarDuracao(relatorio.tempoMedioPorPedidoSegundos)}`);
      doc.text(`Pedidos por hora: ${relatorio.pedidosPorHora}`);
      doc.text(`Itens por hora: ${relatorio.itensPorHora}`);
      doc.text(`Eficiência: ${relatorio.eficienciaPercentual}%`);
      doc.text(`Aproveitamento da jornada: ${relatorio.aproveitamentoJornadaPercentual}%`);
      doc.moveDown();

      doc.fontSize(14).text('Tempo por atividade', { underline: true });
      doc.fontSize(11);
      for (const [atividade, segundos] of Object.entries(relatorio.tempoPorAtividade)) {
        doc.text(`${atividade}: ${formatarDuracao(segundos)}`);
      }
      doc.moveDown();

      doc.fontSize(14).text('Histórico', { underline: true });
      doc.fontSize(9);
      for (const h of relatorio.historico) {
        const linha = `${new Date(h.horaInicio).toLocaleString('pt-BR')} | ${h.tipoAtividade} | ` +
          `${h.duracaoSegundos ? formatarDuracao(h.duracaoSegundos) : '-'} | ` +
          `Pedidos: ${h.quantidadePedidos ?? 0} | Itens: ${h.quantidadeItens ?? 0} | ${h.status}`;
        doc.text(linha);
      }

      doc.end();
    });
  }
}

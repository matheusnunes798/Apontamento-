// Caminho: backend/src/modules/relatorios/relatorios.controller.ts

import { Controller, Get, Param, Query, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { Permissao } from '@prisma/client';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RelatoriosService } from './relatorios.service';
import { ExportacaoService } from './exportacao.service';
import { PeriodoRelatorioDto } from './dto/periodo-relatorio.dto';

@Controller('relatorios')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
export class RelatoriosController {
  constructor(
    private readonly relatoriosService: RelatoriosService,
    private readonly exportacaoService: ExportacaoService,
  ) {}

  @Get('funcionario/:id')
  relatorioFuncionario(@Param('id') id: string, @Query() dto: PeriodoRelatorioDto) {
    return this.relatoriosService.relatorioFuncionario(id, dto);
  }

  @Get('equipe/:id')
  relatorioEquipe(@Param('id') id: string, @Query() dto: PeriodoRelatorioDto) {
    return this.relatoriosService.relatorioEquipe(id, dto);
  }

  @Get('setor/:id')
  relatorioSetor(@Param('id') id: string, @Query() dto: PeriodoRelatorioDto) {
    return this.relatoriosService.relatorioSetor(id, dto);
  }

  @Get('funcionario/:id/exportar/excel')
  async exportarExcel(@Param('id') id: string, @Query() dto: PeriodoRelatorioDto, @Res() res: Response) {
    const relatorio = await this.relatoriosService.relatorioFuncionario(id, dto);
    const buffer = await this.exportacaoService.paraExcel(relatorio);

    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="relatorio-${relatorio.funcionario.matricula}.xlsx"`,
    });
    res.send(buffer);
  }

  @Get('funcionario/:id/exportar/pdf')
  async exportarPdf(@Param('id') id: string, @Query() dto: PeriodoRelatorioDto, @Res() res: Response) {
    const relatorio = await this.relatoriosService.relatorioFuncionario(id, dto);
    const buffer = await this.exportacaoService.paraPdf(relatorio);

    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="relatorio-${relatorio.funcionario.matricula}.pdf"`,
    });
    res.send(buffer);
  }
}

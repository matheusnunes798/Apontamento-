// Caminho: backend/src/modules/relatorios/relatorios.service.ts

import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { StatusRegistroAtividade } from '@prisma/client';
import { PrismaService } from '../../infra/prisma/prisma.service';
import { PeriodoRelatorioDto, TipoPeriodo } from './dto/periodo-relatorio.dto';

export interface IntervaloData {
  inicio: Date;
  fim: Date;
}

export interface RelatorioFuncionario {
  funcionario: { id: string; nome: string; matricula: string; cargo: string };
  periodo: IntervaloData;
  tempoTotalTrabalhadoSegundos: number;
  tempoPorAtividade: Record<string, number>;
  tempoOciosoSegundos: number;
  quantidadePedidos: number;
  quantidadeItens: number;
  tempoMedioPorPedidoSegundos: number;
  pedidosPorHora: number;
  itensPorHora: number;
  eficienciaPercentual: number;
  aproveitamentoJornadaPercentual: number;
  historico: Array<{
    id: string;
    tipoAtividade: string;
    horaInicio: Date;
    horaFim: Date | null;
    duracaoSegundos: number | null;
    quantidadePedidos: number | null;
    quantidadeItens: number | null;
    observacoes: string | null;
    status: string;
  }>;
}

const JORNADA_PADRAO_SEGUNDOS = 8 * 3600; // usado quando o funcionário não tem turno cadastrado

@Injectable()
export class RelatoriosService {
  constructor(private readonly prisma: PrismaService) {}

  resolverIntervalo(dto: PeriodoRelatorioDto): IntervaloData {
    const hoje = new Date();

    switch (dto.tipo) {
      case TipoPeriodo.DIARIO: {
        const inicio = new Date(hoje);
        inicio.setHours(0, 0, 0, 0);
        const fim = new Date(hoje);
        fim.setHours(23, 59, 59, 999);
        return { inicio, fim };
      }
      case TipoPeriodo.SEMANAL: {
        const diaSemana = hoje.getDay();
        const inicio = new Date(hoje);
        inicio.setDate(hoje.getDate() - diaSemana);
        inicio.setHours(0, 0, 0, 0);
        const fim = new Date(inicio);
        fim.setDate(inicio.getDate() + 6);
        fim.setHours(23, 59, 59, 999);
        return { inicio, fim };
      }
      case TipoPeriodo.MENSAL: {
        const inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1, 0, 0, 0, 0);
        const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0, 23, 59, 59, 999);
        return { inicio, fim };
      }
      case TipoPeriodo.PERSONALIZADO: {
        if (!dto.dataInicio || !dto.dataFim) {
          throw new BadRequestException(
            'Para período personalizado, informe dataInicio e dataFim.',
          );
        }
        const inicio = new Date(dto.dataInicio);
        inicio.setHours(0, 0, 0, 0);
        const fim = new Date(dto.dataFim);
        fim.setHours(23, 59, 59, 999);
        if (inicio > fim) {
          throw new BadRequestException('dataInicio não pode ser posterior a dataFim.');
        }
        return { inicio, fim };
      }
    }
  }

  async relatorioFuncionario(funcionarioId: string, dto: PeriodoRelatorioDto): Promise<RelatorioFuncionario> {
    const funcionario = await this.prisma.funcionario.findUnique({
      where: { id: funcionarioId },
      select: { id: true, nome: true, matricula: true, cargo: true, turno: true },
    });

    if (!funcionario) {
      throw new NotFoundException('Funcionário não encontrado.');
    }

    const periodo = this.resolverIntervalo(dto);

    const registros = await this.prisma.registroAtividade.findMany({
      where: {
        funcionarioId,
        dataInicio: { gte: periodo.inicio, lte: periodo.fim },
      },
      orderBy: { dataInicio: 'desc' },
    });

    const finalizados = registros.filter((r) => r.status === StatusRegistroAtividade.FINALIZADO);

    const tempoTotalTrabalhadoSegundos = finalizados.reduce((s, r) => s + (r.duracaoSegundos ?? 0), 0);
    const quantidadePedidos = finalizados.reduce((s, r) => s + (r.quantidadePedidos ?? 0), 0);
    const quantidadeItens = finalizados.reduce((s, r) => s + (r.quantidadeItens ?? 0), 0);

    const tempoPorAtividade: Record<string, number> = {};
    for (const r of finalizados) {
      tempoPorAtividade[r.tipoAtividade] = (tempoPorAtividade[r.tipoAtividade] ?? 0) + (r.duracaoSegundos ?? 0);
    }

    // Jornada esperada no período: turno do funcionário × nº de dias do intervalo,
    // ou jornada padrão de 8h caso não tenha turno cadastrado.
    const diasNoPeriodo = Math.max(
      1,
      Math.ceil((periodo.fim.getTime() - periodo.inicio.getTime()) / (1000 * 60 * 60 * 24)),
    );
    const jornadaDiariaSegundos = funcionario.turno
      ? this.duracaoTurnoEmSegundos(funcionario.turno.horaInicio, funcionario.turno.horaFim)
      : JORNADA_PADRAO_SEGUNDOS;
    const jornadaTotalSegundos = jornadaDiariaSegundos * diasNoPeriodo;

    const tempoOciosoSegundos = Math.max(0, jornadaTotalSegundos - tempoTotalTrabalhadoSegundos);

    return {
      funcionario: {
        id: funcionario.id,
        nome: funcionario.nome,
        matricula: funcionario.matricula,
        cargo: funcionario.cargo,
      },
      periodo,
      tempoTotalTrabalhadoSegundos,
      tempoPorAtividade,
      tempoOciosoSegundos,
      quantidadePedidos,
      quantidadeItens,
      tempoMedioPorPedidoSegundos: quantidadePedidos
        ? Math.round(tempoTotalTrabalhadoSegundos / quantidadePedidos)
        : 0,
      pedidosPorHora: tempoTotalTrabalhadoSegundos > 0
        ? Number(((quantidadePedidos / tempoTotalTrabalhadoSegundos) * 3600).toFixed(2))
        : 0,
      itensPorHora: tempoTotalTrabalhadoSegundos > 0
        ? Number(((quantidadeItens / tempoTotalTrabalhadoSegundos) * 3600).toFixed(2))
        : 0,
      // Eficiência: quanto do tempo trabalhado teve produção registrada (proxy simples;
      // pode ser refinado por atividade/meta específica no futuro).
      eficienciaPercentual: jornadaTotalSegundos > 0
        ? Number(((tempoTotalTrabalhadoSegundos / jornadaTotalSegundos) * 100).toFixed(1))
        : 0,
      aproveitamentoJornadaPercentual: jornadaTotalSegundos > 0
        ? Number((((jornadaTotalSegundos - tempoOciosoSegundos) / jornadaTotalSegundos) * 100).toFixed(1))
        : 0,
      historico: registros.map((r) => ({
        id: r.id,
        tipoAtividade: r.tipoAtividade,
        horaInicio: r.horaInicio,
        horaFim: r.horaFim,
        duracaoSegundos: r.duracaoSegundos,
        quantidadePedidos: r.quantidadePedidos,
        quantidadeItens: r.quantidadeItens,
        observacoes: r.observacoes,
        status: r.status,
      })),
    };
  }

  async relatorioEquipe(equipeId: string, dto: PeriodoRelatorioDto) {
    const equipe = await this.prisma.equipe.findUnique({
      where: { id: equipeId },
      include: { funcionarios: { where: { ativo: true } } },
    });

    if (!equipe) {
      throw new NotFoundException('Equipe não encontrada.');
    }

    const relatoriosIndividuais = await Promise.all(
      equipe.funcionarios.map((f) => this.relatorioFuncionario(f.id, dto)),
    );

    return this.consolidar(equipe.nome, relatoriosIndividuais);
  }

  async relatorioSetor(setorId: string, dto: PeriodoRelatorioDto) {
    const setor = await this.prisma.setor.findUnique({
      where: { id: setorId },
      include: { funcionarios: { where: { ativo: true } } },
    });

    if (!setor) {
      throw new NotFoundException('Setor não encontrado.');
    }

    const relatoriosIndividuais = await Promise.all(
      setor.funcionarios.map((f) => this.relatorioFuncionario(f.id, dto)),
    );

    return this.consolidar(setor.nome, relatoriosIndividuais);
  }

  private consolidar(nomeGrupo: string, relatorios: RelatorioFuncionario[]) {
    const totalPedidos = relatorios.reduce((s, r) => s + r.quantidadePedidos, 0);
    const totalItens = relatorios.reduce((s, r) => s + r.quantidadeItens, 0);
    const totalTrabalhado = relatorios.reduce((s, r) => s + r.tempoTotalTrabalhadoSegundos, 0);
    const totalOcioso = relatorios.reduce((s, r) => s + r.tempoOciosoSegundos, 0);

    return {
      grupo: nomeGrupo,
      totalFuncionarios: relatorios.length,
      totalPedidos,
      totalItens,
      tempoTotalTrabalhadoSegundos: totalTrabalhado,
      tempoTotalOciosoSegundos: totalOcioso,
      eficienciaMediaPercentual: relatorios.length
        ? Number((relatorios.reduce((s, r) => s + r.eficienciaPercentual, 0) / relatorios.length).toFixed(1))
        : 0,
      porFuncionario: relatorios,
    };
  }

  private duracaoTurnoEmSegundos(horaInicio: string, horaFim: string): number {
    const [hIni, mIni] = horaInicio.split(':').map(Number);
    const [hFim, mFim] = horaFim.split(':').map(Number);
    let minutos = (hFim * 60 + mFim) - (hIni * 60 + mIni);
    if (minutos <= 0) minutos += 24 * 60; // turno que cruza a meia-noite
    return minutos * 60;
  }
}

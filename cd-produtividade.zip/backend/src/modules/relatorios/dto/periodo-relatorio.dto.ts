// Caminho: backend/src/modules/relatorios/dto/periodo-relatorio.dto.ts

import { IsEnum, IsOptional, IsDateString } from 'class-validator';

export enum TipoPeriodo {
  DIARIO = 'diario',
  SEMANAL = 'semanal',
  MENSAL = 'mensal',
  PERSONALIZADO = 'personalizado',
}

export class PeriodoRelatorioDto {
  @IsEnum(TipoPeriodo, { message: 'Tipo de período inválido.' })
  tipo: TipoPeriodo;

  // Obrigatório apenas quando tipo = personalizado (validado no service,
  // já que class-validator não faz validação condicional simples aqui)
  @IsOptional()
  @IsDateString()
  dataInicio?: string;

  @IsOptional()
  @IsDateString()
  dataFim?: string;
}

// Caminho: backend/src/modules/relatorios/relatorios.module.ts

import { Module } from '@nestjs/common';
import { RelatoriosService } from './relatorios.service';
import { ExportacaoService } from './exportacao.service';
import { RelatoriosController } from './relatorios.controller';

@Module({
  controllers: [RelatoriosController],
  providers: [RelatoriosService, ExportacaoService],
})
export class RelatoriosModule {}

// Caminho: backend/src/modules/atividades/atividades.controller.ts

import {
  Controller,
  Get,
  Post,
  Patch,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser, UsuarioAutenticado } from '../../common/decorators/current-user.decorator';
import { AtividadesService } from './atividades.service';
import { IniciarAtividadeDto } from './dto/iniciar-atividade.dto';
import { EncerrarAtividadeDto } from './dto/encerrar-atividade.dto';
import { FiltroAtividadesDto } from './dto/filtro-atividades.dto';

@Controller('atividades')
@UseGuards(JwtAuthGuard)
export class AtividadesController {
  constructor(private readonly atividadesService: AtividadesService) {}

  @Post('iniciar')
  iniciar(@Body() dto: IniciarAtividadeDto, @CurrentUser() usuario: UsuarioAutenticado) {
    return this.atividadesService.iniciar(dto, usuario);
  }

  @Patch(':id/encerrar')
  encerrar(
    @Param('id') id: string,
    @Body() dto: EncerrarAtividadeDto,
    @CurrentUser() usuario: UsuarioAutenticado,
  ) {
    return this.atividadesService.encerrar(id, dto, usuario);
  }

  // Usado pelo front do funcionário para saber, ao logar, se já existe
  // uma atividade em aberto (ex.: recarregou a página no meio do turno).
  @Get('em-andamento/:funcionarioId')
  atividadeEmAndamento(@Param('funcionarioId') funcionarioId: string) {
    return this.atividadesService.atividadeAbertaDoFuncionario(funcionarioId);
  }

  @Get()
  listar(@Query() filtro: FiltroAtividadesDto) {
    return this.atividadesService.listar(filtro);
  }
}

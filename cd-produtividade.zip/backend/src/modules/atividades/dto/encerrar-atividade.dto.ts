// Caminho: backend/src/modules/atividades/dto/encerrar-atividade.dto.ts

import { IsInt, IsOptional, IsString, Min, MaxLength } from 'class-validator';

export class EncerrarAtividadeDto {
  @IsOptional()
  @IsInt({ message: 'Quantidade de pedidos deve ser um número inteiro.' })
  @Min(0)
  quantidadePedidos?: number;

  @IsOptional()
  @IsInt({ message: 'Quantidade de itens deve ser um número inteiro.' })
  @Min(0)
  quantidadeItens?: number;

  @IsOptional()
  @IsString()
  @MaxLength(500, { message: 'Observações devem ter no máximo 500 caracteres.' })
  observacoes?: string;
}

// Caminho: backend/src/modules/atividades/dto/iniciar-atividade.dto.ts

import { IsEnum, IsOptional, IsUUID } from 'class-validator';
import { TipoAtividade } from '@prisma/client';

export class IniciarAtividadeDto {
  @IsEnum(TipoAtividade, { message: 'Tipo de atividade inválido.' })
  tipoAtividade: TipoAtividade;

  // Preenchido pelo próprio funcionário logado; admin/supervisor podem
  // iniciar em nome de outro funcionário (ex.: coletor sem login individual).
  @IsOptional()
  @IsUUID()
  funcionarioId?: string;
}

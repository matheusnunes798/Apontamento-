// Caminho: backend/src/modules/atividades/dto/filtro-atividades.dto.ts

import { IsOptional, IsUUID, IsEnum, IsDateString } from 'class-validator';
import { TipoAtividade, StatusRegistroAtividade } from '@prisma/client';

export class FiltroAtividadesDto {
  @IsOptional()
  @IsUUID()
  funcionarioId?: string;

  @IsOptional()
  @IsUUID()
  setorId?: string;

  @IsOptional()
  @IsUUID()
  equipeId?: string;

  @IsOptional()
  @IsEnum(TipoAtividade)
  tipoAtividade?: TipoAtividade;

  @IsOptional()
  @IsEnum(StatusRegistroAtividade)
  status?: StatusRegistroAtividade;

  @IsOptional()
  @IsDateString()
  dataInicio?: string;

  @IsOptional()
  @IsDateString()
  dataFim?: string;
}

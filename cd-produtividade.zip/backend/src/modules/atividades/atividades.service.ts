// Caminho: backend/src/modules/atividades/atividades.service.ts

import {
  Injectable,
  ConflictException,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Prisma, StatusRegistroAtividade } from '@prisma/client';
import { PrismaService } from '../../infra/prisma/prisma.service';
import { IniciarAtividadeDto } from './dto/iniciar-atividade.dto';
import { EncerrarAtividadeDto } from './dto/encerrar-atividade.dto';
import { FiltroAtividadesDto } from './dto/filtro-atividades.dto';
import { UsuarioAutenticado } from '../../common/decorators/current-user.decorator';

// Código do erro do Postgres para violação de constraint única.
// Usado como segunda linha de defesa contra condição de corrida,
// além da verificação feita antes do insert.
const POSTGRES_UNIQUE_VIOLATION = 'P2002';

@Injectable()
export class AtividadesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  async iniciar(dto: IniciarAtividadeDto, usuario: UsuarioAutenticado) {
    const funcionarioId = this.resolverFuncionarioAlvo(dto.funcionarioId, usuario);

    const atividadeAberta = await this.prisma.registroAtividade.findFirst({
      where: { funcionarioId, status: StatusRegistroAtividade.ABERTO },
    });

    if (atividadeAberta) {
      throw new ConflictException(
        `Este funcionário já possui uma atividade em andamento (${atividadeAberta.tipoAtividade}). ` +
          'Encerre-a antes de iniciar outra.',
      );
    }

    try {
      const agora = new Date();
      const registro = await this.prisma.registroAtividade.create({
        data: {
          funcionarioId,
          tipoAtividade: dto.tipoAtividade,
          dataInicio: agora,
          horaInicio: agora,
          status: StatusRegistroAtividade.ABERTO,
        },
        include: { funcionario: { select: { nome: true, setorId: true, equipeId: true } } },
      });

      this.eventEmitter.emit('atividade.iniciada', registro);

      return registro;
    } catch (erro) {
      // Camada de proteção contra corrida: se dois requests concorrentes
      // passarem pela checagem acima ao mesmo tempo, o índice único parcial
      // do banco (ver migration) rejeita o segundo insert.
      if (erro instanceof Prisma.PrismaClientKnownRequestError && erro.code === POSTGRES_UNIQUE_VIOLATION) {
        throw new ConflictException('Este funcionário já possui uma atividade em andamento.');
      }
      throw erro;
    }
  }

  async encerrar(registroId: string, dto: EncerrarAtividadeDto, usuario: UsuarioAutenticado) {
    const registro = await this.prisma.registroAtividade.findUnique({
      where: { id: registroId },
    });

    if (!registro) {
      throw new NotFoundException('Registro de atividade não encontrado.');
    }

    if (registro.status !== StatusRegistroAtividade.ABERTO) {
      throw new ConflictException('Esta atividade já foi finalizada ou cancelada.');
    }

    this.garantirAcessoAoRegistro(registro.funcionarioId, usuario);

    const agora = new Date();
    const duracaoSegundos = Math.max(
      0,
      Math.floor((agora.getTime() - registro.horaInicio.getTime()) / 1000),
    );

    const registroAtualizado = await this.prisma.registroAtividade.update({
      where: { id: registroId },
      data: {
        dataFim: agora,
        horaFim: agora,
        duracaoSegundos,
        quantidadePedidos: dto.quantidadePedidos ?? 0,
        quantidadeItens: dto.quantidadeItens ?? 0,
        observacoes: dto.observacoes,
        status: StatusRegistroAtividade.FINALIZADO,
      },
      include: { funcionario: { select: { nome: true, setorId: true, equipeId: true } } },
    });

    this.eventEmitter.emit('atividade.encerrada', registroAtualizado);

    return registroAtualizado;
  }

  async atividadeAbertaDoFuncionario(funcionarioId: string) {
    return this.prisma.registroAtividade.findFirst({
      where: { funcionarioId, status: StatusRegistroAtividade.ABERTO },
    });
  }

  async listar(filtro: FiltroAtividadesDto) {
    const where: Prisma.RegistroAtividadeWhereInput = {
      funcionarioId: filtro.funcionarioId,
      tipoAtividade: filtro.tipoAtividade,
      status: filtro.status,
      funcionario: filtro.setorId || filtro.equipeId
        ? { setorId: filtro.setorId, equipeId: filtro.equipeId }
        : undefined,
    };

    if (filtro.dataInicio || filtro.dataFim) {
      where.dataInicio = {
        gte: filtro.dataInicio ? new Date(filtro.dataInicio) : undefined,
        lte: filtro.dataFim ? new Date(filtro.dataFim + 'T23:59:59') : undefined,
      };
    }

    return this.prisma.registroAtividade.findMany({
      where,
      include: {
        funcionario: {
          select: { id: true, nome: true, matricula: true, setorId: true, equipeId: true },
        },
      },
      orderBy: { dataInicio: 'desc' },
    });
  }

  /**
   * Um funcionário comum só pode iniciar/encerrar a própria atividade.
   * Admin/supervisor podem operar em nome de qualquer funcionário
   * (ex.: quando o coletor de dados não tem login individual).
   */
  private resolverFuncionarioAlvo(funcionarioIdInformado: string | undefined, usuario: UsuarioAutenticado): string {
    if (!funcionarioIdInformado || funcionarioIdInformado === usuario.id) {
      return usuario.id;
    }

    if (usuario.permissao === 'ADMINISTRADOR' || usuario.permissao === 'SUPERVISOR') {
      return funcionarioIdInformado;
    }

    throw new ForbiddenException('Você só pode registrar suas próprias atividades.');
  }

  private garantirAcessoAoRegistro(funcionarioIdDoRegistro: string, usuario: UsuarioAutenticado): void {
    const ehDono = funcionarioIdDoRegistro === usuario.id;
    const ehGestor = usuario.permissao === 'ADMINISTRADOR' || usuario.permissao === 'SUPERVISOR';

    if (!ehDono && !ehGestor) {
      throw new ForbiddenException('Você não tem permissão para alterar esta atividade.');
    }
  }
}

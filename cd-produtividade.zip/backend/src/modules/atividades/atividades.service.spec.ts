// Caminho: backend/src/modules/atividades/atividades.service.spec.ts

import { ConflictException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { StatusRegistroAtividade } from '@prisma/client';
import { AtividadesService } from './atividades.service';
import { UsuarioAutenticado } from '../../common/decorators/current-user.decorator';

describe('AtividadesService', () => {
  let service: AtividadesService;
  let prismaMock: any;
  let eventEmitterMock: any;

  const funcionario: UsuarioAutenticado = {
    id: 'func-1',
    login: 'joao.silva',
    permissao: 'FUNCIONARIO',
    setorId: 'setor-1',
  };

  beforeEach(() => {
    prismaMock = {
      registroAtividade: {
        findFirst: jest.fn(),
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        findMany: jest.fn(),
      },
    };
    eventEmitterMock = { emit: jest.fn() };
    service = new AtividadesService(prismaMock, eventEmitterMock);
  });

  describe('iniciar', () => {
    it('deve impedir iniciar uma atividade se já existe uma aberta', async () => {
      prismaMock.registroAtividade.findFirst.mockResolvedValue({
        id: 'reg-existente',
        tipoAtividade: 'SEPARACAO',
        status: StatusRegistroAtividade.ABERTO,
      });

      await expect(
        service.iniciar({ tipoAtividade: 'PICKING' } as any, funcionario),
      ).rejects.toThrow(ConflictException);

      expect(prismaMock.registroAtividade.create).not.toHaveBeenCalled();
    });

    it('deve criar o registro e emitir o evento quando não há atividade aberta', async () => {
      prismaMock.registroAtividade.findFirst.mockResolvedValue(null);
      const registroCriado = {
        id: 'reg-novo',
        tipoAtividade: 'PICKING',
        funcionarioId: funcionario.id,
        status: StatusRegistroAtividade.ABERTO,
        funcionario: { nome: 'João Silva' },
      };
      prismaMock.registroAtividade.create.mockResolvedValue(registroCriado);

      const resultado = await service.iniciar({ tipoAtividade: 'PICKING' } as any, funcionario);

      expect(resultado).toEqual(registroCriado);
      expect(eventEmitterMock.emit).toHaveBeenCalledWith('atividade.iniciada', registroCriado);
    });

    it('funcionário comum não pode iniciar atividade em nome de outro', async () => {
      prismaMock.registroAtividade.findFirst.mockResolvedValue(null);

      await expect(
        service.iniciar({ tipoAtividade: 'PICKING', funcionarioId: 'outro-func' } as any, funcionario),
      ).rejects.toThrow(ForbiddenException);
    });

    it('supervisor pode iniciar atividade em nome de outro funcionário', async () => {
      const supervisor: UsuarioAutenticado = { ...funcionario, id: 'sup-1', permissao: 'SUPERVISOR' };
      prismaMock.registroAtividade.findFirst.mockResolvedValue(null);
      prismaMock.registroAtividade.create.mockResolvedValue({ id: 'reg-x', funcionarioId: 'outro-func' });

      await service.iniciar({ tipoAtividade: 'PICKING', funcionarioId: 'outro-func' } as any, supervisor);

      expect(prismaMock.registroAtividade.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ funcionarioId: 'outro-func' }) }),
      );
    });
  });

  describe('encerrar', () => {
    it('deve calcular a duração corretamente e mudar o status para FINALIZADO', async () => {
      const horaInicio = new Date(Date.now() - 60_000); // 60s atrás
      prismaMock.registroAtividade.findUnique.mockResolvedValue({
        id: 'reg-1',
        funcionarioId: funcionario.id,
        horaInicio,
        status: StatusRegistroAtividade.ABERTO,
      });
      prismaMock.registroAtividade.update.mockImplementation(({ data }: any) => ({
        id: 'reg-1',
        ...data,
      }));

      const resultado = await service.encerrar('reg-1', { quantidadePedidos: 5, quantidadeItens: 20 }, funcionario);

      expect(resultado.status).toBe(StatusRegistroAtividade.FINALIZADO);
      expect(resultado.duracaoSegundos).toBeGreaterThanOrEqual(59);
      expect(eventEmitterMock.emit).toHaveBeenCalledWith('atividade.encerrada', expect.any(Object));
    });

    it('deve lançar NotFoundException se o registro não existir', async () => {
      prismaMock.registroAtividade.findUnique.mockResolvedValue(null);

      await expect(service.encerrar('inexistente', {}, funcionario)).rejects.toThrow(NotFoundException);
    });

    it('deve impedir encerrar um registro que já está finalizado', async () => {
      prismaMock.registroAtividade.findUnique.mockResolvedValue({
        id: 'reg-1',
        funcionarioId: funcionario.id,
        status: StatusRegistroAtividade.FINALIZADO,
      });

      await expect(service.encerrar('reg-1', {}, funcionario)).rejects.toThrow(ConflictException);
    });

    it('funcionário comum não pode encerrar atividade de outro funcionário', async () => {
      prismaMock.registroAtividade.findUnique.mockResolvedValue({
        id: 'reg-1',
        funcionarioId: 'outro-func',
        status: StatusRegistroAtividade.ABERTO,
        horaInicio: new Date(),
      });

      await expect(service.encerrar('reg-1', {}, funcionario)).rejects.toThrow(ForbiddenException);
    });
  });
});

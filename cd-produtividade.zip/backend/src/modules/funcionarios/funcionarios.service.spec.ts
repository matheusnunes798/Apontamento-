// Caminho: backend/src/modules/funcionarios/funcionarios.service.spec.ts

import { ConflictException, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { FuncionariosService } from './funcionarios.service';

describe('FuncionariosService', () => {
  let service: FuncionariosService;
  let prismaMock: any;

  beforeEach(() => {
    prismaMock = {
      funcionario: {
        findUnique: jest.fn(),
        create: jest.fn(),
        update: jest.fn(),
        findMany: jest.fn(),
      },
      logAuditoria: { create: jest.fn() },
      refreshToken: { updateMany: jest.fn() },
    };
    service = new FuncionariosService(prismaMock);
  });

  describe('criar', () => {
    it('deve rejeitar criação com matrícula já existente', async () => {
      prismaMock.funcionario.findUnique
        .mockResolvedValueOnce({ id: 'existente' }) // matrícula
        .mockResolvedValueOnce(null); // login

      await expect(
        service.criar({
          nome: 'Teste',
          matricula: '000001',
          cargo: 'Operador',
          login: 'teste',
          senha: 'senha123',
          permissao: 'FUNCIONARIO' as any,
          setorId: 'setor-1',
        }),
      ).rejects.toThrow(ConflictException);
    });

    it('deve rejeitar criação com login já existente', async () => {
      prismaMock.funcionario.findUnique
        .mockResolvedValueOnce(null) // matrícula
        .mockResolvedValueOnce({ id: 'existente' }); // login

      await expect(
        service.criar({
          nome: 'Teste',
          matricula: '000002',
          cargo: 'Operador',
          login: 'joao.silva',
          senha: 'senha123',
          permissao: 'FUNCIONARIO' as any,
          setorId: 'setor-1',
        }),
      ).rejects.toThrow(ConflictException);
    });

    it('nunca deve retornar o hash da senha no objeto criado', async () => {
      prismaMock.funcionario.findUnique.mockResolvedValue(null);
      prismaMock.funcionario.create.mockImplementation(({ select }: any) => {
        // Simula o comportamento do Prisma respeitando o `select`
        expect(select.senhaHash).toBeUndefined();
        return { id: 'novo', nome: 'Teste' };
      });

      await service.criar({
        nome: 'Teste',
        matricula: '000003',
        cargo: 'Operador',
        login: 'novo.func',
        senha: 'senha123',
        permissao: 'FUNCIONARIO' as any,
        setorId: 'setor-1',
      });
    });
  });

  describe('trocarSenha', () => {
    it('deve rejeitar se a senha atual estiver incorreta', async () => {
      const senhaHash = await bcrypt.hash('senha-correta', 10);
      prismaMock.funcionario.findUnique.mockResolvedValue({ id: 'func-1', senhaHash });

      await expect(
        service.trocarSenha('func-1', { senhaAtual: 'senha-errada', novaSenha: 'nova123456' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('deve revogar todos os refresh tokens ao trocar a senha com sucesso', async () => {
      const senhaHash = await bcrypt.hash('senha-correta', 10);
      prismaMock.funcionario.findUnique.mockResolvedValue({ id: 'func-1', senhaHash });
      prismaMock.funcionario.update.mockResolvedValue({});

      await service.trocarSenha('func-1', { senhaAtual: 'senha-correta', novaSenha: 'nova123456' });

      expect(prismaMock.refreshToken.updateMany).toHaveBeenCalledWith(
        expect.objectContaining({ where: { funcionarioId: 'func-1', revogado: false } }),
      );
    });
  });
});

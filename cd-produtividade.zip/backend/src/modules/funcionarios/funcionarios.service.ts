// Caminho: backend/src/modules/funcionarios/funcionarios.service.ts

import {
  Injectable,
  ConflictException,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../../infra/prisma/prisma.service';
import { CreateFuncionarioDto } from './dto/create-funcionario.dto';
import { UpdateFuncionarioDto } from './dto/update-funcionario.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { AcaoAuditoria } from '@prisma/client';

const SALT_ROUNDS = 10;

// Campos seguros para retornar ao cliente (nunca expor senhaHash)
const SELECT_SEGURO = {
  id: true,
  nome: true,
  matricula: true,
  cargo: true,
  login: true,
  permissao: true,
  ativo: true,
  setorId: true,
  equipeId: true,
  turnoId: true,
  criadoEm: true,
  atualizadoEm: true,
} as const;

@Injectable()
export class FuncionariosService {
  constructor(private readonly prisma: PrismaService) {}

  async criar(dto: CreateFuncionarioDto, autorId?: string) {
    const [matriculaExiste, loginExiste] = await Promise.all([
      this.prisma.funcionario.findUnique({ where: { matricula: dto.matricula } }),
      this.prisma.funcionario.findUnique({ where: { login: dto.login } }),
    ]);

    if (matriculaExiste) {
      throw new ConflictException('Já existe um funcionário com esta matrícula.');
    }
    if (loginExiste) {
      throw new ConflictException('Já existe um funcionário com este login.');
    }

    const senhaHash = await bcrypt.hash(dto.senha, SALT_ROUNDS);

    const funcionario = await this.prisma.funcionario.create({
      data: {
        nome: dto.nome,
        matricula: dto.matricula,
        cargo: dto.cargo,
        login: dto.login,
        senhaHash,
        permissao: dto.permissao,
        setorId: dto.setorId,
        equipeId: dto.equipeId,
        turnoId: dto.turnoId,
      },
      select: SELECT_SEGURO,
    });

    await this.registrarAuditoria(AcaoAuditoria.CRIACAO, funcionario.id, autorId, null, funcionario);

    return funcionario;
  }

  async listar(filtros: { setorId?: string; equipeId?: string; ativo?: boolean }) {
    return this.prisma.funcionario.findMany({
      where: {
        setorId: filtros.setorId,
        equipeId: filtros.equipeId,
        ativo: filtros.ativo,
      },
      select: SELECT_SEGURO,
      orderBy: { nome: 'asc' },
    });
  }

  async buscarPorId(id: string) {
    const funcionario = await this.prisma.funcionario.findUnique({
      where: { id },
      select: SELECT_SEGURO,
    });

    if (!funcionario) {
      throw new NotFoundException('Funcionário não encontrado.');
    }

    return funcionario;
  }

  async atualizar(id: string, dto: UpdateFuncionarioDto, autorId?: string) {
    const existente = await this.buscarPorId(id);

    const funcionario = await this.prisma.funcionario.update({
      where: { id },
      data: dto,
      select: SELECT_SEGURO,
    });

    await this.registrarAuditoria(AcaoAuditoria.ATUALIZACAO, id, autorId, existente, funcionario);

    return funcionario;
  }

  async inativar(id: string, autorId?: string) {
    const existente = await this.buscarPorId(id);

    const funcionario = await this.prisma.funcionario.update({
      where: { id },
      data: { ativo: false },
      select: SELECT_SEGURO,
    });

    await this.registrarAuditoria(AcaoAuditoria.EXCLUSAO, id, autorId, existente, funcionario);

    return funcionario;
  }

  async trocarSenha(id: string, dto: ChangePasswordDto) {
    const funcionario = await this.prisma.funcionario.findUnique({ where: { id } });

    if (!funcionario) {
      throw new NotFoundException('Funcionário não encontrado.');
    }

    const senhaConfere = await bcrypt.compare(dto.senhaAtual, funcionario.senhaHash);
    if (!senhaConfere) {
      throw new UnauthorizedException('Senha atual incorreta.');
    }

    const novaSenhaHash = await bcrypt.hash(dto.novaSenha, SALT_ROUNDS);

    await this.prisma.funcionario.update({
      where: { id },
      data: { senhaHash: novaSenhaHash },
    });

    // Revoga todos os refresh tokens ativos ao trocar a senha (segurança)
    await this.prisma.refreshToken.updateMany({
      where: { funcionarioId: id, revogado: false },
      data: { revogado: true },
    });

    return { mensagem: 'Senha atualizada com sucesso.' };
  }

  private async registrarAuditoria(
    acao: AcaoAuditoria,
    entidadeId: string,
    autorId: string | undefined,
    dadosAntes: unknown,
    dadosDepois: unknown,
  ) {
    await this.prisma.logAuditoria.create({
      data: {
        funcionarioId: autorId,
        acao,
        entidade: 'Funcionario',
        entidadeId,
        dadosAntes: dadosAntes as any,
        dadosDepois: dadosDepois as any,
      },
    });
  }
}

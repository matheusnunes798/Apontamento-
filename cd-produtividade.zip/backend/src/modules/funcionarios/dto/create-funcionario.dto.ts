// Caminho: backend/src/modules/funcionarios/dto/create-funcionario.dto.ts

import {
  IsString,
  IsNotEmpty,
  MinLength,
  IsEnum,
  IsUUID,
  IsOptional,
} from 'class-validator';
import { Permissao } from '@prisma/client';

export class CreateFuncionarioDto {
  @IsString()
  @IsNotEmpty({ message: 'O nome é obrigatório.' })
  nome: string;

  @IsString()
  @IsNotEmpty({ message: 'A matrícula é obrigatória.' })
  matricula: string;

  @IsString()
  @IsNotEmpty({ message: 'O cargo é obrigatório.' })
  cargo: string;

  @IsString()
  @IsNotEmpty({ message: 'O login é obrigatório.' })
  login: string;

  @IsString()
  @MinLength(6, { message: 'A senha deve ter ao menos 6 caracteres.' })
  senha: string;

  @IsEnum(Permissao, { message: 'Permissão inválida.' })
  permissao: Permissao;

  @IsUUID()
  setorId: string;

  @IsOptional()
  @IsUUID()
  equipeId?: string;

  @IsOptional()
  @IsUUID()
  turnoId?: string;
}

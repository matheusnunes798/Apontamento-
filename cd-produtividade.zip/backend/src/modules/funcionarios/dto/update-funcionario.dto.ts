// Caminho: backend/src/modules/funcionarios/dto/update-funcionario.dto.ts

import { PartialType, OmitType } from '@nestjs/mapped-types';
import { CreateFuncionarioDto } from './create-funcionario.dto';
import { IsBoolean, IsOptional } from 'class-validator';

// Senha não é atualizada por este DTO (tem endpoint próprio de troca de senha)
export class UpdateFuncionarioDto extends PartialType(
  OmitType(CreateFuncionarioDto, ['senha'] as const),
) {
  @IsOptional()
  @IsBoolean()
  ativo?: boolean;
}

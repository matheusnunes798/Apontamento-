// Caminho: backend/src/modules/funcionarios/funcionarios.controller.ts

import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { Permissao } from '@prisma/client';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser, UsuarioAutenticado } from '../../common/decorators/current-user.decorator';
import { FuncionariosService } from './funcionarios.service';
import { CreateFuncionarioDto } from './dto/create-funcionario.dto';
import { UpdateFuncionarioDto } from './dto/update-funcionario.dto';
import { ChangePasswordDto } from './dto/change-password.dto';

@Controller('funcionarios')
@UseGuards(JwtAuthGuard, RolesGuard)
export class FuncionariosController {
  constructor(private readonly funcionariosService: FuncionariosService) {}

  @Post()
  @Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
  criar(@Body() dto: CreateFuncionarioDto, @CurrentUser() usuario: UsuarioAutenticado) {
    return this.funcionariosService.criar(dto, usuario.id);
  }

  @Get()
  @Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
  listar(
    @Query('setorId') setorId?: string,
    @Query('equipeId') equipeId?: string,
    @Query('ativo') ativo?: string,
  ) {
    return this.funcionariosService.listar({
      setorId,
      equipeId,
      ativo: ativo === undefined ? undefined : ativo === 'true',
    });
  }

  @Get(':id')
  @Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
  buscarPorId(@Param('id') id: string) {
    return this.funcionariosService.buscarPorId(id);
  }

  @Patch(':id')
  @Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
  atualizar(
    @Param('id') id: string,
    @Body() dto: UpdateFuncionarioDto,
    @CurrentUser() usuario: UsuarioAutenticado,
  ) {
    return this.funcionariosService.atualizar(id, dto, usuario.id);
  }

  @Delete(':id')
  @Roles(Permissao.ADMINISTRADOR)
  inativar(@Param('id') id: string, @CurrentUser() usuario: UsuarioAutenticado) {
    return this.funcionariosService.inativar(id, usuario.id);
  }

  // Qualquer funcionário autenticado pode trocar a própria senha
  @Patch(':id/senha')
  trocarSenha(
    @Param('id') id: string,
    @Body() dto: ChangePasswordDto,
    @CurrentUser() usuario: UsuarioAutenticado,
  ) {
    // Um funcionário comum só pode trocar a própria senha;
    // admin/supervisor podem trocar de qualquer um (ex.: reset).
    if (
      usuario.id !== id &&
      usuario.permissao !== Permissao.ADMINISTRADOR &&
      usuario.permissao !== Permissao.SUPERVISOR
    ) {
      id = usuario.id; // força o próprio id, ignorando tentativa de alterar outro
    }
    return this.funcionariosService.trocarSenha(id, dto);
  }
}

// Caminho: backend/src/modules/dashboard/dashboard.gateway.ts

import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { OnEvent } from '@nestjs/event-emitter';
import { Server, Socket } from 'socket.io';
import { Logger, UseGuards } from '@nestjs/common';
import { DashboardService, FiltroDashboard } from './dashboard.service';

/**
 * Namespace dedicado ao dashboard. O front do gestor conecta em
 * ws://<host>/dashboard e recebe eventos em tempo real sempre que
 * alguém inicia ou encerra uma atividade — sem precisar dar polling.
 */
@WebSocketGateway({
  namespace: 'dashboard',
  cors: { origin: process.env.CORS_ORIGIN ?? 'http://localhost:5173' },
})
export class DashboardGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger('DashboardGateway');

  constructor(private readonly dashboardService: DashboardService) {}

  handleConnection(client: Socket) {
    this.logger.log(`Cliente conectado ao dashboard: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Cliente desconectado do dashboard: ${client.id}`);
  }

  // O front pode pedir um snapshot atualizado a qualquer momento
  // (ex.: ao aplicar um filtro de setor/equipe/turno).
  @SubscribeMessage('dashboard:solicitar-snapshot')
  async solicitarSnapshot(
    @MessageBody() filtro: FiltroDashboard,
    @ConnectedSocket() client: Socket,
  ) {
    const snapshot = await this.dashboardService.snapshot(filtro ?? {});
    client.emit('dashboard:snapshot', snapshot);
  }

  // Reage aos eventos emitidos pelo AtividadesService (desacoplado via EventEmitter2 —
  // o módulo de Atividades não conhece o WebSocket, só emite o fato de domínio).
  @OnEvent('atividade.iniciada')
  async aoIniciarAtividade(registro: any) {
    this.server.emit('atividade:iniciada', {
      funcionarioId: registro.funcionarioId,
      nome: registro.funcionario?.nome,
      tipoAtividade: registro.tipoAtividade,
      horaInicio: registro.horaInicio,
    });
    // Reenvia um snapshot geral para manter contadores/rankings coerentes
    this.server.emit('dashboard:snapshot', await this.dashboardService.snapshot({}));
  }

  @OnEvent('atividade.encerrada')
  async aoEncerrarAtividade(registro: any) {
    this.server.emit('atividade:encerrada', {
      funcionarioId: registro.funcionarioId,
      nome: registro.funcionario?.nome,
      tipoAtividade: registro.tipoAtividade,
      duracaoSegundos: registro.duracaoSegundos,
      quantidadePedidos: registro.quantidadePedidos,
      quantidadeItens: registro.quantidadeItens,
    });
    this.server.emit('dashboard:snapshot', await this.dashboardService.snapshot({}));
  }
}

// Caminho: backend/src/modules/dashboard/dashboard.service.ts

import { Injectable } from '@nestjs/common';
import { StatusRegistroAtividade } from '@prisma/client';
import { PrismaService } from '../../infra/prisma/prisma.service';

export interface FiltroDashboard {
  setorId?: string;
  equipeId?: string;
  turnoId?: string;
  data?: string; // YYYY-MM-DD, default: hoje
}

@Injectable()
export class DashboardService {
  constructor(private readonly prisma: PrismaService) {}

  /** Snapshot completo usado tanto na carga inicial via REST quanto ao reconectar o socket. */
  async snapshot(filtro: FiltroDashboard) {
    const [emAndamento, parados, resumoAtividades, ranking] = await Promise.all([
      this.funcionariosEmAndamento(filtro),
      this.funcionariosParados(filtro),
      this.resumoAtividades(filtro),
      this.rankingProdutividade(filtro),
    ]);

    return {
      funcionariosAtivos: emAndamento.length,
      funcionariosParados: parados.length,
      emAndamento,
      parados,
      resumoAtividades,
      ranking,
      atualizadoEm: new Date().toISOString(),
    };
  }

  async funcionariosEmAndamento(filtro: FiltroDashboard) {
    const registros = await this.prisma.registroAtividade.findMany({
      where: {
        status: StatusRegistroAtividade.ABERTO,
        funcionario: {
          setorId: filtro.setorId,
          equipeId: filtro.equipeId,
          turnoId: filtro.turnoId,
        },
      },
      include: {
        funcionario: { select: { id: true, nome: true, matricula: true, setorId: true, equipeId: true } },
      },
    });

    return registros.map((registro) => ({
      funcionarioId: registro.funcionario.id,
      nome: registro.funcionario.nome,
      matricula: registro.funcionario.matricula,
      atividade: registro.tipoAtividade,
      iniciadaEm: registro.horaInicio,
      segundosEmAndamento: Math.floor((Date.now() - registro.horaInicio.getTime()) / 1000),
    }));
  }

  /**
   * "Parado" = funcionário ativo do setor/equipe filtrado que não possui
   * nenhum registro ABERTO no momento. Cruza a lista de funcionários com
   * a lista de quem está com atividade aberta.
   */
  async funcionariosParados(filtro: FiltroDashboard) {
    const [todosFuncionarios, comAtividadeAberta] = await Promise.all([
      this.prisma.funcionario.findMany({
        where: {
          ativo: true,
          setorId: filtro.setorId,
          equipeId: filtro.equipeId,
          turnoId: filtro.turnoId,
        },
        select: { id: true, nome: true, matricula: true },
      }),
      this.prisma.registroAtividade.findMany({
        where: { status: StatusRegistroAtividade.ABERTO },
        select: { funcionarioId: true },
      }),
    ]);

    const idsComAtividade = new Set(comAtividadeAberta.map((r) => r.funcionarioId));
    const parados = todosFuncionarios.filter((f) => !idsComAtividade.has(f.id));

    // Para calcular há quanto tempo está parado, buscamos o último registro finalizado de cada um.
    const resultados = await Promise.all(
      parados.map(async (funcionario) => {
        const ultimoRegistro = await this.prisma.registroAtividade.findFirst({
          where: { funcionarioId: funcionario.id, status: StatusRegistroAtividade.FINALIZADO },
          orderBy: { dataFim: 'desc' },
        });

        const desde = ultimoRegistro?.dataFim ?? null;

        return {
          funcionarioId: funcionario.id,
          nome: funcionario.nome,
          matricula: funcionario.matricula,
          paradoDesde: desde,
          segundosParado: desde ? Math.floor((Date.now() - desde.getTime()) / 1000) : null,
        };
      }),
    );

    return resultados;
  }

  async resumoAtividades(filtro: FiltroDashboard) {
    const dataAlvo = filtro.data ? new Date(filtro.data) : new Date();
    const inicioDoDia = new Date(dataAlvo.setHours(0, 0, 0, 0));
    const fimDoDia = new Date(dataAlvo.setHours(23, 59, 59, 999));

    const registrosFinalizadosHoje = await this.prisma.registroAtividade.findMany({
      where: {
        status: StatusRegistroAtividade.FINALIZADO,
        dataInicio: { gte: inicioDoDia, lte: fimDoDia },
        funcionario: {
          setorId: filtro.setorId,
          equipeId: filtro.equipeId,
          turnoId: filtro.turnoId,
        },
      },
    });

    const pedidosConcluidos = registrosFinalizadosHoje.reduce((soma, r) => soma + (r.quantidadePedidos ?? 0), 0);
    const itensProcessados = registrosFinalizadosHoje.reduce((soma, r) => soma + (r.quantidadeItens ?? 0), 0);
    const duracaoTotalSegundos = registrosFinalizadosHoje.reduce((soma, r) => soma + (r.duracaoSegundos ?? 0), 0);
    const horasTrabalhadas = duracaoTotalSegundos / 3600;

    const registrosEmAndamento = await this.prisma.registroAtividade.count({
      where: {
        status: StatusRegistroAtividade.ABERTO,
        funcionario: {
          setorId: filtro.setorId,
          equipeId: filtro.equipeId,
          turnoId: filtro.turnoId,
        },
      },
    });

    return {
      pedidosEmAndamento: registrosEmAndamento,
      pedidosConcluidos,
      itensProcessados,
      tempoMedioPorAtividadeSegundos: registrosFinalizadosHoje.length
        ? Math.round(duracaoTotalSegundos / registrosFinalizadosHoje.length)
        : 0,
      tempoMedioPorPedidoSegundos: pedidosConcluidos
        ? Math.round(duracaoTotalSegundos / pedidosConcluidos)
        : 0,
      pedidosPorHora: horasTrabalhadas > 0 ? Number((pedidosConcluidos / horasTrabalhadas).toFixed(2)) : 0,
      itensPorHora: horasTrabalhadas > 0 ? Number((itensProcessados / horasTrabalhadas).toFixed(2)) : 0,
    };
  }

  async rankingProdutividade(filtro: FiltroDashboard) {
    const dataAlvo = filtro.data ? new Date(filtro.data) : new Date();
    const inicioDoDia = new Date(dataAlvo.setHours(0, 0, 0, 0));
    const fimDoDia = new Date(dataAlvo.setHours(23, 59, 59, 999));

    const registros = await this.prisma.registroAtividade.findMany({
      where: {
        status: StatusRegistroAtividade.FINALIZADO,
        dataInicio: { gte: inicioDoDia, lte: fimDoDia },
        funcionario: {
          setorId: filtro.setorId,
          equipeId: filtro.equipeId,
          turnoId: filtro.turnoId,
        },
      },
      include: { funcionario: { select: { id: true, nome: true, matricula: true } } },
    });

    const porFuncionario = new Map<
      string,
      { nome: string; matricula: string; pedidos: number; itens: number; segundos: number }
    >();

    for (const registro of registros) {
      const atual = porFuncionario.get(registro.funcionarioId) ?? {
        nome: registro.funcionario.nome,
        matricula: registro.funcionario.matricula,
        pedidos: 0,
        itens: 0,
        segundos: 0,
      };
      atual.pedidos += registro.quantidadePedidos ?? 0;
      atual.itens += registro.quantidadeItens ?? 0;
      atual.segundos += registro.duracaoSegundos ?? 0;
      porFuncionario.set(registro.funcionarioId, atual);
    }

    const lista = Array.from(porFuncionario.entries()).map(([funcionarioId, dados]) => ({
      funcionarioId,
      ...dados,
      pedidosPorHora: dados.segundos > 0 ? Number(((dados.pedidos / dados.segundos) * 3600).toFixed(2)) : 0,
    }));

    return {
      produtividade: [...lista].sort((a, b) => b.pedidosPorHora - a.pedidosPorHora).slice(0, 10),
      tempoOcioso: [...lista].sort((a, b) => a.segundos - b.segundos).slice(0, 10),
    };
  }
}

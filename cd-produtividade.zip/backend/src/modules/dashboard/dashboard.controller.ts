// Caminho: backend/src/modules/dashboard/dashboard.controller.ts

import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { Permissao } from '@prisma/client';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { DashboardService, FiltroDashboard } from './dashboard.service';

@Controller('dashboard')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(Permissao.ADMINISTRADOR, Permissao.SUPERVISOR)
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  @Get('snapshot')
  snapshot(@Query() filtro: FiltroDashboard) {
    return this.dashboardService.snapshot(filtro);
  }
}
